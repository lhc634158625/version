-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[fn_cententypoint]
(
	-- Add the parameters for the function here
	@roadname varchar(500)	
)
RETURNS float
AS
BEGIN
	declare @EdgeId int
    declare @centent float
    
   select @EdgeId=max(a.EdgeId) from 
	(select top (select case  when COUNT(*)/2 =0 then 1 else COUNT(*)/2 end 
		from TrafficInfo where  Direct!=2 and ROADID IN(select ROADID from MAP_ROADINFO where ROADNAME=@roadname)) EdgeId 
	from TrafficInfo where Direct!=2 and ROADID IN(select ROADID from MAP_ROADINFO where ROADNAME=@roadname)) a
	        
	SELECT @centent =(MAX(FromY)+ MAX(ToY))/2
	FROM TrafficInfo
	where EdgeId=@EdgeId
	return @centent
END
GO

