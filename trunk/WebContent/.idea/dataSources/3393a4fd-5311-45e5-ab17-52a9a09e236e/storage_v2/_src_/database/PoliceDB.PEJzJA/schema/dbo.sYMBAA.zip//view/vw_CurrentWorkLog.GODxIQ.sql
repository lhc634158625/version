   create view vw_CurrentWorkLog(ShiftType,ReceiveDt,RegionId,State,Type,Memo)
   as 
   select distinct shifttype,receivedt,regionid,state,TYPE,CAST(memo as varchar(4000))
   from StaffWorkLog
   GO

