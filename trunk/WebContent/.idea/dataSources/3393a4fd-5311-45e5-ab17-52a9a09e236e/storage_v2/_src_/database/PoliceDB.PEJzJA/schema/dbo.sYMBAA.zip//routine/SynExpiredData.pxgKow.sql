
CREATE PROCEDURE [dbo].[SynExpiredData] 
	(@date1 datetime)
AS
BEGIN
	---ArrangeInfo
	Insert Into PoliceDB_his..[ArrangeInfo] select * from PoliceDB..[ArrangeInfo] where WorkDt<dateadd(YEAR,-1,@date1)
	Delete from PoliceDB..[ArrangeInfo] where WorkDt<dateadd(YEAR,-1,@date1)
	
	---CommunicateLog
	Insert Into PoliceDB_his..[CommunicateLog] select * from PoliceDB..[CommunicateLog] where [Created]<dateadd(YEAR,-1,@date1)
	Delete from PoliceDB..[CommunicateLog] where [Created]<dateadd(YEAR,-1,@date1)
	
	---DeviceOnOffline
	--Insert Into PoliceDB_his..[DeviceOnOffline] select * from PoliceDB..[DeviceOnOffline] where [Date]<dateadd(day,-30,@date1)
	--Delete from PoliceDB..[DeviceOnOffline] where [Date]<dateadd(day,-30,@date1)
	
	---MessageInfo
	---Insert Into PoliceDB_his..[MessageInfo] select * from PoliceDB..[MessageInfo] where [Date]<dateadd(day,-30,@date1)
	---Delete from PoliceDB..[MessageInfo] where [Date]<dateadd(day,-30,@date1)
	
	---ParkingOverTime
	Insert Into PoliceDB_his..[ParkingOverTime] select * from PoliceDB..[ParkingOverTime] where [BeginTime]<dateadd(YEAR,-1,@date1)
	Delete from PoliceDB..[ParkingOverTime] where [BeginTime]<dateadd(YEAR,-1,@date1)
	
	---RegionService
	--Insert Into PoliceDB_his..[RegionService] select * from PoliceDB..[RegionService] where [ReceiveDt]<dateadd(YEAR,-1,@date1)
	--Delete from PoliceDB..[RegionService] where [ReceiveDt]<dateadd(YEAR,-1,@date1)
	
	---StaffCheckIn
	Insert Into PoliceDB_his..[StaffCheckIn] select * from PoliceDB..[StaffCheckIn] where [CheckInDt]<dateadd(YEAR,-1,@date1)
	Delete from PoliceDB..[StaffCheckIn] where [CheckInDt]<dateadd(YEAR,-1,@date1)
	
	---StaffWorkLog
	Insert Into PoliceDB_his..[StaffWorkLog] select * from PoliceDB..[StaffWorkLog] where [ReceiveDt]<dateadd(YEAR,-1,@date1)
	Delete from PoliceDB..[StaffWorkLog] where [ReceiveDt]<dateadd(YEAR,-1,@date1)
	
END

GO

