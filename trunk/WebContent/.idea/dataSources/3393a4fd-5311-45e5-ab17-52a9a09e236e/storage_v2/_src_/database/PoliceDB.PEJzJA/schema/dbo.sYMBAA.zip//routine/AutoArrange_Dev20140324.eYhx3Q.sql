
CREATE PROCEDURE [dbo].[AutoArrange_Dev20140324] 
	(@workDt Date)
AS
BEGIN
	---分配到警务区
	insert into ArrangeInfo(StaffId,WorkDt,ShiftType,StaffName,StationId,RegionId,timetype,TimeName,FromTime,totime)
	select distinct b.Id,@workDt,a.ShiftType,b.Name,a.StationId,a.RegionId,a.TimeType,a.TimeName,a.FromTime,a.Totime
	from ArrangeInfo a,DeviceInfo b 
	where a.WorkDt=@workDt and a.ShiftType=4 and a.RegionId=b.RegionId and b.Type='巡逻车台'
		and not exists (select 1 from ArrangeInfo where  ArrangeInfo.WorkDt=@workDt and ArrangeInfo.StaffId=b.Id)

	---单警务区未分配到警务区
	insert into ArrangeInfo(StaffId,WorkDt,ShiftType,StaffName,StationId,RegionId,timetype,TimeName,FromTime,totime)
	select distinct b.Id,@workDt,a.ShiftType,b.Name,a.StationId,a.RegionId,a.TimeType,a.TimeName,a.FromTime,a.Totime
	from ArrangeInfo a,DeviceInfo b 
	where a.WorkDt=@workDt and a.ShiftType=4 and a.StationId=b.StationId and b.Type='巡逻车台'
		and not exists (select 1 from ArrangeInfo where  ArrangeInfo.WorkDt=@workDt and ArrangeInfo.StaffId=b.Id)
		and b.StationId in (select StationId from SubRegion group by StationId having count(StationId)=1)
END

GO

