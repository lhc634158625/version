
CREATE procedure [dbo].[sp_UpdateRoadType] (@roadid int, @type int)
  as
  begin
  declare @oldId int
  set  @oldId=@roadid
  if(@oldId>2000) set @oldId=@roadid -2000
  if(@oldId>1000) set @oldId=@roadid -1000
  
update MAP_ROADINFO set ROADTYPE=@type where ROADID=@roadid;
update TrafficInfo set RoadType=@type where RoadId=@roadid;
update MAP_ROADEDGE set ROADTYPE=@type where roadid=@roadid;
update MAP_EDGEDATA set ROADTYPE=@type where ROADID=@roadid;
  end
GO

