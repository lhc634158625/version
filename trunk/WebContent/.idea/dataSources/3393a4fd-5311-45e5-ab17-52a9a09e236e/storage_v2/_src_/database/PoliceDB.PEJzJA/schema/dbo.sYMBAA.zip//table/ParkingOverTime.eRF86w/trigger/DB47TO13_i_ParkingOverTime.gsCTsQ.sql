/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_i_ParkingOverTime] 
   ON  [dbo].[ParkingOverTime]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO13' ,'dbo'  ,'ParkingOverTime' ,'ID=' + convert(varchar(50),inserted.ID) ,'I',0, 'IDB47TO13dboParkingOverTimeID=' + convert(varchar(50),inserted.ID) 
    from inserted
END
GO

