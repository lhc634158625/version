CREATE procedure [dbo].[SP_PushToGPS_temp]
as
begin
-- 同步到gps系统
 BEGIN TRY
 
declare @maxId int
declare @minId int
 
 select @minId=TempId from SynDataLog
 select @maxId= MAX(id)  from RegionService
 if @maxId>(@minId+50) 
 begin
	set @maxId=@minId+50
 end
 
 if @maxId >1418558
 begin
	set @maxId=1418558
 end
 
 
 insert into [GPSCENTER].[TXServer].[dbo].[ReportToPolice](
      [VehicleID]
      ,[PoliceName]
      ,[Station]
      ,[Region]
      ,[ReportName]
      ,[Longitude]
      ,[Latitude]
      ,[ReportTele]
      ,[ReportAddress]
      ,[ReportSituation]
      ,[SaveTime]
      ,[ReportType]
      ,[Code]
      ,[OperationType]
      ,[Unit]      
      )
select a.DevCode,a.Name,a.Station,a.Region,SUBSTRING(b.reportName,0,25),ROUND(b.Longitude,6),ROUND(b.Latitude,6), SUBSTRING(b.ReportTel,0,50),SUBSTRING(b.ReportAddress,0,100),SUBSTRING(b.Memo,0,2000),b.ReceiveDt,b.TypeName,b.Code,0,'指挥中心'
from vw_RegionVerhicleInfo a,RegionService b
where (a.RegionId=b.RegionId and a.StationId=b.StationId)
	and b.Id>=@minId and b.Id<@maxId
	and SUBSTRING(a.DevCode,0,2)='1'
	and SUBSTRING(b.Memo,0,7)!='<分局上报>'
	

insert into [GPSCENTER].[TXServer].[dbo].[ReportToPolice](
      [VehicleID]
      ,[PoliceName]
      ,[Station]
      ,[Region]
      ,[ReportName]
      ,[Longitude]
      ,[Latitude]
      ,[ReportTele]
      ,[ReportAddress]
      ,[ReportSituation]
      ,[SaveTime]
      ,[ReportType]
      ,[Code]
      ,[OperationType]
      ,[Unit]      
      )
select a.DevCode,a.Name,a.Station,NULL,SUBSTRING(b.reportName,0,25), ROUND(b.Longitude,6),ROUND(b.Latitude,6), SUBSTRING(b.ReportTel,0,50),SUBSTRING(b.ReportAddress,0,100),SUBSTRING(b.Memo,0,2000),b.ReceiveDt,b.TypeName,b.Code,0,'指挥中心'
from vw_RegionVerhicleInfo a,RegionService b
where (b.RegionId=0 and a.StationId=b.StationId)
	and b.Id>=@minId and b.Id<@maxId
	and SUBSTRING(a.DevCode,0,2)='1'
	and SUBSTRING(b.Memo,0,7)!='<分局上报>'

---警务区警情 
 insert into [GPSCENTER].[TXServer].[dbo].[ReportToPolice2](
      [VehicleID]
      ,[PoliceName]
      ,[Station]
      ,[Region]
      ,[ReportName]
      ,[Longitude]
      ,[Latitude]
      ,[ReportTele]
      ,[ReportAddress]
      ,[ReportSituation]
      ,[SaveTime]
      ,[CaseType]
      ,[ReportType]
      ,[Code]
      ,[OperationType]
      ,[Unit]
      )
select  a.DevCode,a.Name,a.Station,a.Region,SUBSTRING(b.reportName,0,25), ROUND(b.Longitude,6),ROUND(b.Latitude,6), SUBSTRING(b.ReportTel,0,50),SUBSTRING(b.ReportAddress,0,100),SUBSTRING(b.Memo,0,2000),b.ReceiveDt,b.TypeName,b.TypeName,b.Code,0,'指挥中心'
from vw_RegionHandset a,RegionService b
where (a.RegionId=b.RegionId and a.RegionId>0 and a.StationId=b.StationId)
	and b.Id>=@minId and b.Id<@maxId
	and SUBSTRING(a.DevCode,0,2)='1'
	and SUBSTRING(b.Memo,0,7)!='<分局上报>'
---未细化到警务区警情发送给所有在班警员	
insert into [GPSCENTER].[TXServer].[dbo].[ReportToPolice2](
      [VehicleID]
      ,[PoliceName]
      ,[Station]
      ,[Region]
      ,[ReportName]
      ,[Longitude]
      ,[Latitude]
      ,[ReportTele]
      ,[ReportAddress]
      ,[ReportSituation]
      ,[SaveTime]
      ,[CaseType]
      ,[ReportType]
      ,[Code]
      ,[OperationType]
      ,[Unit]
      )
select  a.DevCode,a.Name,a.Station,NULL,SUBSTRING(b.reportName,0,25), ROUND(b.Longitude,6),ROUND(b.Latitude,6), SUBSTRING(b.ReportTel,0,50),SUBSTRING(b.ReportAddress,0,100),SUBSTRING(b.Memo,0,2000),b.ReceiveDt,b.TypeName,b.TypeName,b.Code,0,'指挥中心'
from vw_RegionHandset a,RegionService b
where (b.RegionId=0 and a.RegionId>0 and a.StationId=b.StationId)
	and b.Id>=@minId and b.Id<@maxId
	and SUBSTRING(a.DevCode,0,2)='1'
	and SUBSTRING(b.Memo,0,7)!='<分局上报>'

---值班领导收到所有警情
insert into [GPSCENTER].[TXServer].[dbo].[ReportToPolice2](
      [VehicleID]
      ,[PoliceName]
      ,[Station]
      ,[Region]
      ,[ReportName]
      ,[Longitude]
      ,[Latitude]
      ,[ReportTele]
      ,[ReportAddress]
      ,[ReportSituation]
      ,[SaveTime]
      ,[CaseType]
      ,[ReportType]
      ,[Code]
      ,[OperationType]
      ,[Unit]
      )
select  a.DevCode,a.Name,a.Station,NULL,SUBSTRING(b.reportName,0,25), ROUND(b.Longitude,6),ROUND(b.Latitude,6), SUBSTRING(b.ReportTel,0,50),SUBSTRING(b.ReportAddress,0,100),SUBSTRING(b.Memo,0,2000),b.ReceiveDt,b.TypeName,b.TypeName,b.Code,0,'指挥中心'
from vw_RegionHandset a,RegionService b
where (a.StationId=b.StationId and a.RegionId=0)
	and b.Id>=@minId and b.Id<@maxId
	and SUBSTRING(a.DevCode,0,2)='1'
	and SUBSTRING(b.Memo,0,7)!='<分局上报>'


update syndatalog set TempId=@maxId
 	
END TRY
BEGIN CATCH
   -- SELECT ERROR_LINE() AS ErrorLine;
END CATCH;
end
GO

