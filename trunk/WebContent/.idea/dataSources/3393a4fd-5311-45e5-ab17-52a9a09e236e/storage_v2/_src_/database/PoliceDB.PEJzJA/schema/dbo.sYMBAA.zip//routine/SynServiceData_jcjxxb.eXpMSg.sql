
CREATE PROCEDURE [dbo].[SynServiceData_jcjxxb]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN

	declare @maxid varchar(50)
	declare @minid varchar(50)
	select @minid=MaxJCJId from syndatalog
	select @maxid=MAX(id) from [POLICECENTER].[policedb].[dbo].[jcjxxb]
	
	insert into RegionService(ReceiveDt,Type,RegionId,Memo,serviceid,StationId,reportname,reporttel,reportaddress,Longitude,Latitude,typename,JCJId)
	select a.bdate,b.Code,c.Id,a.bz,a.lsh,c.StationId,rtrim([repname1])+RTRIM([repname2]),rtrim([reptele1])+','+RTRIM([connect1]),
	  RTRIM([road])+RTRIM([addrno]),isnull(a.longitude, c.CenterX),isnull(a.latitude,c.CenterY),b.name, a.id									
	from [POLICECENTER].[policedb].[dbo].[jcjxxb] a,ServiceType b	,
	subregion c
	where  a.[id] > @minid and a.[id]<=@maxid
	and a.tool=c.code 	and b.code=a.type	
	order by a.[id]
   
	insert into RegionService(ReceiveDt,Type,RegionId,Memo,serviceid,StationId,reportname,reporttel,reportaddress,Longitude,Latitude,typename,JCJId)
	  select a.bdate,b.Code,0,a.bz,a.lsh,c.Id,rtrim([repname1])+RTRIM([repname2]),rtrim([reptele1])+','+RTRIM([connect1]),
	  RTRIM([road])+RTRIM([addrno]),isnull(a.longitude, c.CenterX),isnull(a.latitude,c.CenterY),b.name, a.id
	from [POLICECENTER].[policedb].[dbo].[jcjxxb] a,ServiceType b	,	
	STATION c
	where  a.[id]> @minid and a.[id]<= @maxid
	and a.JLAREA1=c.InnerCode and a.type=b.code
	AND rtrim(A.tool)=''	
	order by a.[id]
	
	--同步到gps数据库
	exec [SP_PushToGPS] @minId,@maxid
	
	update syndatalog set MaxJCJId=@maxid
	
END
GO

