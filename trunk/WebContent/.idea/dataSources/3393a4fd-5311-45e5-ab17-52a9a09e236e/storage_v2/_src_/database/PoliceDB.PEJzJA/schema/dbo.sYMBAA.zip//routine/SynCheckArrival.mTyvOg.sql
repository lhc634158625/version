CREATE PROCEDURE [dbo].[SynCheckArrival]
	
AS
BEGIN
    --1000米
    update ArrivalInfo set [Memo]=Convert(varchar(30),GETDATE(),120),[State]=CONVERT(int,ArrivalInfo.[State])+1 from InterceptArrange a, Staff b, InterceptPoint c
	where a.StationId=b.Station and a.InterceptPointId=c.Id
	and a.FromTime<=GETDATE() and a.ToTime>=GETDATE() and DATEADD(MI,3,b.LastPosTime)>=GETDATE()
	and dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.CenterX,6),ROUND(c.CenterY,6))<=1000
	and ArrivalInfo.[ObjId]=a.InterceptTaskId and ArrivalInfo.OwnerId=a.InterceptPointId and ArrivalInfo.ObjCode=b.Code
	    
	insert into ArrivalInfo([ObjId],[ObjCode],[ObjName],[StationId],[OwnerId],[OwnerType],[Created],[Longitude],[Latitude],[Distance],[State],[Memo])
	select distinct a.InterceptTaskId,b.Code,b.Name,a.StationId,a.InterceptPointId,'拦截任务排班',GETDATE(),b.Longitude,b.Latitude,
		dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.CenterX,6),ROUND(c.CenterY,6)),'1',GETDATE()
	from InterceptArrange a, Staff b, InterceptPoint c
	where a.StationId=b.Station and a.InterceptPointId=c.Id
	and a.FromTime<=GETDATE() and a.ToTime>=GETDATE() and DATEADD(MI,3,b.LastPosTime)>=GETDATE()
	and dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.CenterX,6),ROUND(c.CenterY,6))<=1000
	and not exists (select 1 from ArrivalInfo where ArrivalInfo.ObjCode=b.Code and ArrivalInfo.[ObjId]=a.InterceptTaskId and ArrivalInfo.[OwnerId]=a.InterceptPointId and ArrivalInfo.OwnerType='拦截任务排班')


END
GO

