

     CREATE view [dbo].[vw_RegionVerhicleInfo_20120621](Name,DevCode,Station,Region,StationId,RegionId)
     as 
     select MAX(a.Name),a.devCode,max(b.Name),MAX(c.Name),MAX(b.id),c.id
     from Staff a,Station b,SubRegion c
     where a.Station=b.Id and a.RegionId=c.Id
     and a.DevCode is not null
     group by c.id,a.devCode

     GO

