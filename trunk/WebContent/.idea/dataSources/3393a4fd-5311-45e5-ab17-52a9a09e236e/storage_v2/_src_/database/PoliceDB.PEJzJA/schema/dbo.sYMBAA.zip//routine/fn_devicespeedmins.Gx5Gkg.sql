CREATE  function [dbo].[fn_devicespeedmins](@MinsStr varchar(6),@mins int, @speed decimal)
returns varchar(6)
as
begin

	if len(@MinsStr)<5 or  @MinsStr is null
	begin
		set @MinsStr='000000'
	end
	
	if @speed <=0
	begin
		return @MinsStr
	end
	
	if @mins < 10 and @speed>0
	begin
		set @mins=1
	end
	else if @mins < 20 and @speed>0
	begin
		set @mins=2
	end
	else if @mins < 30 and @speed>0
	begin
		set @mins=3
	end
	else if @mins < 40 and @speed>0
	begin
		set @mins=4
	end
	else if @mins < 50 and @speed>0
	begin
		set @mins=5
	end
	else if @mins < 60 and @speed>0
	begin
		set @mins=6
	end
		
	
	return SUBSTRING(@MinsStr,1,@mins-1) + '1' + SUBSTRING(@MinsStr,@mins+1,6)
end
GO

