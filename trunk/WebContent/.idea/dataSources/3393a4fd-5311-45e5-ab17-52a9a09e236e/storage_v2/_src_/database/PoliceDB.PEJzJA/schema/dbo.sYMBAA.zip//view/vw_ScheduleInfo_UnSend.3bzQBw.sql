

CREATE view [dbo].[vw_ScheduleInfo_UnSend]
as
select aa.*,bb.Name Region from (
select a.Id, b.Code DevCode, b.Param DevParam, b.Name DevName, b.Type DevType, a.Message, a.SendDt, c.Name Station, b.Longitude,b.Latitude, a.RegionId
from ScheduleInfo a, DeviceInfo b, Station c
where a.StaffId=b.Id and a.StationId=c.Id and a.State='新建') aa
left join SubRegion bb
on aa.RegionId=bb.Id


GO

