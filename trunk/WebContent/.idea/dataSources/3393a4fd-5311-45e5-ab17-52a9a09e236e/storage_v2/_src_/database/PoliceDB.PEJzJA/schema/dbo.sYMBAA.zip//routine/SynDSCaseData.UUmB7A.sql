CREATE PROCEDURE [dbo].[SynDSCaseData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	declare @maxDt datetime
	declare @minDt datetime
	select @minDt=CaseInfoDt from syndatalog
	set @maxDt=GETDATE()	
	set @minDt=DATEADD(MINUTE,-1,@minDt)
	
	declare @sql varchar(4000)
	set @sql='select a.jqh CaseCode,a.BJRXM Reporter,a.BJDH ReportTel,a.bjrlxdh ContactTel,b.lsh Code,a.afdd OccurAddress,
			b.bjsj OccurTime,b.ZBNR Description,d.jc Station,sjbwdm,b.SJC,b.zasfdm, d.jgdm,b.ajlxdm
		from DSECS.V_JJDB a,DSECS.v_jqypb b,DSECS.V_BD_DW d
		where a.jqh=b.jqh and b.sldwdm=d.bh and b.SJC>to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'')'
		
	set @sql='insert into CaseInfo([CASECODE],[REPORTER],[REPORTTEL],[CONTACTTEL],[CODE],[OCCURADDRESS],[OCCURTIME],[CASETYPE],[DESCRIPTION],[STATION],[FABW],[GXSJ],[CrimeMeans],StationCode,Type,StationId) 
		select CaseCode,Reporter,ReportTel,ContactTel,a.Code,OccurAddress,
			OccurTime,b.wholename,Description,Station,sjbwdm,SJC,zasfdm,jgdm,ajlxdm
			,c.Id
		from OpenQuery(DSDB, '''+replace(@sql,'''','''''')+''') a,DSHFType b,station c
		where a.ajlxdm=b.bh   and c.scode=a.jgdm and c.isuse=1 and  NOT EXISTS (SELECT 1 from caseinfo where caseinfo.casecode=a.casecode)'
	print @sql
	exec (@sql)
	
	set @sql='select a.jqh CaseCode,a.BJRXM Reporter,a.BJDH ReportTel,a.bjrlxdh ContactTel,b.lsh Code,a.afdd OccurAddress,
			b.bjsj OccurTime,b.ZBNR Description,d.jc Station,sjbwdm,b.SJC,b.zasfdm,
				
	 d.jgdm
			,b.ajlxdm
		from DSECS.V_JJDB a,DSECS.v_jqypb b,DSECS.V_BD_DW d
		where a.jqh=b.jqh and b.sldwdm=d.bh and b.SJC>to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'')'
		
-- and (AJXZ=''诈骗'' or (fabw=''居民住宅'' and  xzfl=''入室盗窃'') or (fabw=''内部单位'' and ajxz=''盗窃'')) 

	set @sql='update caseinfo set casetype=b.wholename,updatetime=sjc,fabw=dbo.getfabw(a.SJBWDM),type=b.bh,needcallback=b.needcallback,ReportTel=a.ReportTel,CONTACTTEL=a.ContactTel,stationid=c.id,stationcode=c.code,station=c.name
		from OpenQuery(DSDB, '''+replace(@sql,'''','''''')+''') a,DSHFType b,station c
		where  a.ajlxdm=b.bh and  a.casecode=caseinfo.casecode and a.jgdm=c.sCode  and c.isuse=1' 
	print @sql
	exec (@sql)
--从regionService更新经纬度到CaseInfo
  print 'update longitude'
  update CaseInfo set Longitude=r.Longitude ,Latitude=r.Latitude  
  from  (select Longitude,Latitude,Ora_LSH from  RegionService  where ReceiveDt>DATEADD(DAY,-10,GETDATE()))r where
   CaseInfo.GXSJ>convert(varchar(20),@minDt,120) and  CaseInfo.CaseCode=r.Ora_LSH 

  update syndatalog set CaseInfoDt=@maxDt
	
	
END
GO

