



CREATE view [dbo].[vw_UserInfo]
as
select a.[Id]
      ,a.[NickName]
      ,a.[StationId]
      ,a.[Password]
      ,a.[Longitude]
      ,a.[Latitude]
      ,a.[RoleId]
      ,a.[State]
      ,a.[Created]
      ,a.[Zoom]
	,b.Name StationName, b.Code StationCode, c.Name RoleName from UserInfo a
join Station b on a.StationId=b.Id
join [Role] c on a.RoleId=c.Id


GO

