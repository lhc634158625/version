
Create PROCEDURE [dbo].[AutoArrange_PeakSite] 
	(@workDt Date, @updater int)
AS
BEGIN
insert CheckInfo(ObjName,StationId,OwnerId,OwnerType,CheckDt,UpdateTime,Updater,[State],Created)
--declare @workDt date
--declare @updater int
--set @workDt='2015-03-26'
--set @updater=1
select TimeName,StationId,Id,'高峰站点',@workDt,GETDATE(),@updater,'新建',GETDATE() 
from ArrangeInfo where TimeName like '高峰站点\_%' escape '\' and LEN(TimeName)>5
and WorkDt=@workDt and ShiftType=7
and not exists (select 1 from CheckInfo where ArrangeInfo.Id=CheckInfo.OwnerId and CheckInfo.OwnerType='高峰站点' and CheckDt=@workDt)
		
END

GO

