
Create FUNCTION [dbo].[GetChildIdStr]
(
	@idstr varchar(500),	
	@item varchar(50)
)
RETURNS @r TABLE(Id int)
AS
Begin
declare @code varchar(10)

    IF (@item='station_isuse')
		with cte as  
		 (  
			 select Id,PId,IsUse from Station where Id in (select * from f_splitStr(@idstr,',')) and isuse=1
			 union all   
			 select s.Id,s.PId,s.IsUse from Station s inner join cte c on s.pid = c.id  where s.isuse=1
			-- select id from station where code like @code+'%' and isuse=1
		 )
        INSERT @r SELECT Id FROM cte 
   
    IF (@item='station')
		with cte as  
		 (  
			 select Id,PId,IsUse from Station where Id in (select * from f_splitStr(@idstr,','))
			 union all   
			 select s.Id,s.PId,s.IsUse from Station s inner join cte c on s.pid = c.id 
			--select id from station where code like @code+'%'  
		 )
        INSERT @r SELECT Id FROM cte
 RETURN  
   
end
GO

