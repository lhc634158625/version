
CREATE  function [dbo].[fn_speed](@speed int,@cameraspeed int,@busspeed int)
returns int
as
begin
if(@speed<@cameraspeed) set @speed=@cameraspeed
if(@speed<@busspeed) set @speed=@busspeed
if (@speed>30) set @speed=35
if(@speed>15)and(@speed<=30) set @speed=30
if(@speed>5) and (@speed<=15) set @speed=15
if(@speed>0) and (@speed<=5) set @speed=5
return @speed
end
GO

