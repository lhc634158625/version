-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tr_insRegionService]
   ON  [dbo].[RegionService]
   AFTER  UPDATE
AS 
BEGIN
SET NOCOUNT ON;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		
	if update(stationid)
	begin
	
	declare @stationid int;
	declare @newstationid int;
	select @stationid=b.stationid from deleted b;
	select @newstationid=c.stationid from inserted c;
	--print @stationid
	--if @stationid is null and @newstationid>0	
	--print 2
	--else
	--print 1	
	--print @newstationid
	
	
	if @stationid is null and @newstationid>0
	begin
	
	update subregion set servicestate='ll0'
	from inserted
	where inserted.regionid=subregion.id 
	
	update subregion set servicestate='ll0'
	from inserted
	where inserted.stationId=subregion.stationId and inserted.regionid=0 
	
	update regionshifttype  set State='ll0'
	from inserted
	where inserted.regionid=regionshifttype.regionid and regionshifttype.shifttype=4
	
	update regionshifttype  set State='ll0'
	from inserted
	where inserted.stationid=regionshifttype.stationid and regionshifttype.shifttype=4
	and inserted.regionid=0 
	
		
	insert into staffworklog
	(staffid,receivedt,type,regionid,Longitude,Latitude,shifttype,memo,serviceid,state,repLongitude,repLatitude,reportname,reporttel,reportaddress,typename,CASE_ID,StationId)
	select a.id,b.receivedt,b.type,b.regionid,
	a.longitude,a.latitude,4,b.memo,b.serviceid,'ll0',
	case	when b.longitude=0	then c.centerx	else	 b.longitude	 end ,
	 case	when b.latitude=0	then c.centery	else	 b.latitude	 end ,
	 reportname,reporttel,reportaddress,typename,CASE_ID,b.StationId
	from staff a,inserted b,subregion c
	where a.regionid=b.regionid and b.regionid=c.id 
	and a.shifttype=4
	and a.state<>'备勤'
	
	insert into staffworklog
	(staffid,receivedt,type,regionid,Longitude,Latitude,shifttype,memo,serviceid,state,repLongitude,repLatitude,reportname,reporttel,reportaddress,typename,CASE_ID,StationId)
	select a.id,b.receivedt,b.type,b.regionid,a.longitude,b.latitude,4,b.memo,b.serviceid,'ll0',
	case	when b.longitude=0	then c.centerx	else	 b.longitude	 end ,
	 case	when b.latitude=0	then c.centery	else	 b.latitude	 end ,
	 reportname,reporttel,reportaddress,typename,CASE_ID,b.StationId
	from staff a,inserted b,station c
	where a.station=b.stationid and b.stationid=c.id 
	and a.shifttype=4 and b.regionid=0
	and a.state<>'备勤'
    
    
    update [DeviceInfo] set [ServiceId]=a.id
    from inserted a,[DeviceInfo]
    left join Staff b on b.HandsetCode = [DeviceInfo].[Code]
    where a.StationId=[DeviceInfo].[StationId] and  a.RegionId=[DeviceInfo].[RegionId]
    and ((b.State <>'备勤' or [DeviceInfo].Type='巡逻车台'))
    
    
    update subregion set [LastServiceId] =a.id
    from inserted a
    where a.StationId=subregion.[StationId] and a.regionid=0
    
    update subregion set [LastServiceId] =a.id
    from inserted a
    where a.RegionId=subregion.Id
    
    end    
    end
END
GO

