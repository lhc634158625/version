
CREATE view [dbo].[vw_SWATPatrolTask]
as
select t1.WorkDt,t1.DutyNumber,isnull(t2.ArrangeNumber,0) ArrangeNumber,DATEPART(dw,DateAdd(d,-1,t1.WorkDt)) DayOfWeek from 
	(select distinct WorkDt,COUNT(*) DutyNumber from SWATHis group by WorkDt) t1
left join 
	(select WorkDt,COUNT(*) ArrangeNumber from Scheduling group by WorkDt) t2
on t1.WorkDt=t2.WorkDt
GO

