-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tr_insGPSInfo]
   ON  dbo.GPSInfo
   AFTER INSERT
AS 
BEGIN
update Staff set longitude=inserted.longitude,
latitude=inserted.latitude,LastPosTime=inserted.ReceiveDt,
address=inserted.posdesc
from inserted where inserted.devcode=staff.handsetcode or (inserted.devcode=staff.devcode  and rtrim(staff.handsetcode) ='')

update DeviceInfo set longitude=inserted.longitude,latitude=inserted.latitude,
	LastPosTime=inserted.ReceiveDt,address=inserted.posdesc, UpdateDt=getdate()
from inserted where inserted.devcode=DeviceInfo.Code 

insert into [DeviceOnOffline](code,[date],[hour],MinsStr,StationId,RegionId,UserId,BindType,Type)
select g.DevCode,g.date,g.hour,g.minsstr,g.StationId,g.RegionId,g.UserId,g.BindType,g.Type
from (
SELECT [DevCode]
		,convert(varchar(10),[ReceiveDt],120) date
		,DATEPART(hour,[ReceiveDt]) hour
		,'000000' minsstr
		,d.StationId
		,d.RegionId
		,d.UserId
		,d.BindType
		,d.Type	
FROM inserted g, DeviceInfo d
where g.DevCode = d.Code
group by DevCode,convert(varchar(10),[ReceiveDt],120),DATEPART(hour,[ReceiveDt]),StationId,RegionId,UserId,BindType,Type ) g
where  not exists(select 1 from DeviceOnOffline where DeviceOnOffline.code=g.DevCode and DeviceOnOffline.date=g.date and DeviceOnOffline.hour=g.hour )

update DeviceOnOffline set DeviceOnOffline.MinsStr=dbo.fn_deviceonoffline(MinsStr,DATEPART(MINUTE,inserted.ReceiveDt), inserted.[Speed]), DeviceOnOffline.SpeedMins=dbo.fn_devicespeedmins(SpeedMins,DATEPART(MINUTE,inserted.ReceiveDt), inserted.[Speed])
from inserted
where DeviceOnOffline.code=inserted.DevCode and DeviceOnOffline.date=convert(varchar(10),inserted.ReceiveDt,120) and DeviceOnOffline.hour=DATEPART(hour,inserted.ReceiveDt)
	

END
GO

