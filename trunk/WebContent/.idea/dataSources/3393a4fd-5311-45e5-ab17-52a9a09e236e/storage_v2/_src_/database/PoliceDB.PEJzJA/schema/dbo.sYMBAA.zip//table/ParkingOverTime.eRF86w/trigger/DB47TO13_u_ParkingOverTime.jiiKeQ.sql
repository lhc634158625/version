/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_u_ParkingOverTime] 
   ON  [dbo].[ParkingOverTime]
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;	
    declare @Remark nvarchar(MAX)
    set @Remark= ''
    
set @Remark='NULL'    

    if @Remark !=''
    BEGIN
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey],[Fields])
    select 'DB47TO13' ,'dbo'  ,'ParkingOverTime' ,'ID=' + convert(varchar(50),inserted.ID),'U',0, 'UDB47TO13dboParkingOverTimeID=' + convert(varchar(50),inserted.ID),@Remark
    from inserted
    End
END
GO

