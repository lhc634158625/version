
CREATE PROCEDURE [dbo].[SP_AddRouteDetail]
	@routeId int,
	@fromx float,
	@fromy float,
	@tox float,
	@toy float,
	@creater int
AS
BEGIN
	declare @newfromx float,@newfromy float,@distance1 float,@distance2 float
	if(@fromx=0)
	begin
	--获取起点
	select top 1 @fromx=fromx,@fromy=fromy,@distance1=dbo.fn_distance(fromx,fromy,@tox,@toy) from RoutePlanDetail
	where RouteId=@routeId order by dbo.fn_distance(fromx,fromy,@tox,@toy)
	select top 1 @newfromx=tox,@newfromy=toy,@distance2=dbo.fn_distance(tox,toy,@tox,@toy) from RoutePlanDetail
	where RouteId=@routeId order by dbo.fn_distance(tox,toy,@tox,@toy)
	if(@distance1>@distance2)
		begin
			set @fromx=@newfromx
			set @fromy=@newfromy
		end
	end
	if(@fromx=0) return
	insert into routeplandetail(routeid,roadid,roadname,roaddirect,roadtype,edgeid,fromx,fromy,tox,toy,state,creater,created)
	values(@routeid,0,'未确定',1,5,0,@fromx,@fromy,@tox,@toy,'确定',@creater,getdate())
	
END
GO

