


CREATE view [dbo].[vw_sum_today]([来源],[今日数量],[说明])
as
select '排班',COUNT(*),MAX(FromTime) from ArrangeInfo with(nolock) where DATEDIFF(D,WorkDt,GETDATE())=0
union
select 'GPS',COUNT(*),MAX([StorageTime]) from GPSInfo with(nolock) where DATEDIFF(D,[StorageTime],GETDATE())=0
union
select 'GPS本地时间',COUNT(*),MAX([CreateTime]) from GPSInfo with(nolock) where DATEDIFF(D,[CreateTime],GETDATE())=0
union
select '需回访案件',COUNT(*),MAX(Created) from CaseInfo with(nolock) where DATEDIFF(D, Created,GETDATE())=0
union
select '路况',COUNT(*),MAX(ChangeDt) from TrafficInfo with(nolock) where DATEDIFF(D, ChangeDt,GETDATE())=0
union
select '巡逻车台',COUNT(*),MAX(LoginInDate) from VehicleState with(nolock) where DATEDIFF(D, LoginInDate,GETDATE())=0
union
select '出租车聚集预警',COUNT(*),MAX(CurrTime) from TaxiAlamInfo with(nolock) where DATEDIFF(D, CurrTime,GETDATE())=0
union
select '接处警',COUNT(*),MAX(ReceiveDt) from RegionService with(nolock) where DATEDIFF(D, ReceiveDt,GETDATE())=0


GO

