/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_d_TaxiAlamCarList] 
   ON  [dbo].[TaxiAlamCarList]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO13' ,'dbo'  ,'TaxiAlamCarList' ,'Id=' + convert(varchar(50),deleted.Id),'D',0,'DDB47TO13dboTaxiAlamCarListId=' + convert(varchar(50),deleted.Id) 
    from deleted
END
GO

DISABLE TRIGGER DB47TO13_d_TaxiAlamCarList ON TaxiAlamCarList
GO

