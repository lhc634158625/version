
-- =============================================
CREATE PROCEDURE [dbo].[SysData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	--exec SynCommData	
	--exec SynServiceData	
	--exec SP_PushToGPS
	exec AutoFinishService
	--exec [dbo].[SynGPSData]	
	--exec [SynResultData]	
	--exec [SP_PushToGPS_temp]
END
GO

