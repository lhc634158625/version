/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_u_Staff] 
   ON  [dbo].[Staff]
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;	
    declare @Remark nvarchar(MAX)
    set @Remark= ''
    

    if update(Name) BEGIN SET @Remark = @Remark +'Name,' END
    if update(Gender) BEGIN SET @Remark = @Remark +'Gender,' END
    if update(Station) BEGIN SET @Remark = @Remark +'Station,' END
    if update(Telephone) BEGIN SET @Remark = @Remark +'Telephone,' END
    if update(Position) BEGIN SET @Remark = @Remark +'Position,' END
    if update(ShiftType) BEGIN SET @Remark = @Remark +'ShiftType,' END
    if update(RegionId) BEGIN SET @Remark = @Remark +'RegionId,' END
    if update(Code) BEGIN SET @Remark = @Remark +'Code,' END
    if update(PyCode) BEGIN SET @Remark = @Remark +'PyCode,' END                                            
    if update(DevType) BEGIN SET @Remark = @Remark +'DevType,' END
    if update(TimeType) BEGIN SET @Remark = @Remark +'TimeType,' END
    if update(HandsetCode) BEGIN SET @Remark = @Remark +'HandsetCode,' END
    if update(IsDel) BEGIN SET @Remark = @Remark +'IsDel,' END
    if update(IdCode) BEGIN SET @Remark = @Remark +'IdCode,' END    
    if update(LeaderPost) BEGIN SET @Remark = @Remark +'LeaderPost,' END    
    if update(NonLeaderPost) BEGIN SET @Remark = @Remark +'NonLeaderPost,' END    

    if @Remark !=''
    BEGIN
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey],[Fields])
    select 'DB47TO13' ,'dbo'  ,'Staff' ,'Id=' + convert(varchar(50),inserted.Id),'U',0, 'UDB47TO13dboStaffId=' + convert(varchar(50),inserted.Id),@Remark
    from inserted
    End
END
GO

