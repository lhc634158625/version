CREATE PROCEDURE [dbo].[AutoArrange] 
	(@Day int,@today Date,@stationid int)
AS
BEGIN

insert into ArrangeInfo(StaffId,WorkDt,ShiftType,StaffName,StationId,RegionId,timetype,TimeName,FromTime,totime)
select distinct a.StaffId,@today,a.ShiftType,a.StaffName,a.StationId,a.RegionId,a.TimeType,b.Name,
	CAST(convert(char(10),@today,120)+' '+convert(char(8),b.fromtime) as datetime),
	case 
	when b.FromTime>=b.ToTime then
		CAST(convert(char(10), DATEADD(d,1, @today),120)+' '+convert(char(8),b.totime) as datetime)
	else
		CAST(convert(char(10),@today,120)+' '+convert(char(8),b.totime) as datetime)
	end 
from ArrangeInfo a,ShiftTime b, RegionShiftType c 
where a.TimeType=b.Id and WorkDt=DATEADD(day, -c.ShiftDays, @today) and a.StationId=@stationid
	and StaffId not in(select StaffId from ArrangeInfo where  WorkDt=@today and StationId=@stationid)
	and b.IsDel=0 and b.StationId=c.StationId and b.RegionId=c.RegionId and b.ShiftId=c.ShiftType
	and c.IsDel=0 and exists(select Id from staff where a.StaffId=staff.Id and staff.Station=@stationid)
END
GO

