CREATE PROCEDURE [dbo].[AutoArrange_Dev] 
	(@workDt Date)
AS
BEGIN
	---2014-3-24修改为与人员排班无关联
	---分配到警务区
	insert into ArrangeInfo(StaffId,WorkDt,ShiftType,StaffName,StationId,RegionId,timetype,TimeName,FromTime,totime)
	select Id,@workDt,4,Name,StationId,RegionId,-999,'巡逻车台',
		CAST(convert(char(10),@workDt,120)+' 08:00:00' as datetime),
		CAST(convert(char(10),DATEADD(d,1,@workDt),120)+' 08:00:00' as datetime)
	from DeviceInfo 
	where [Type]='巡逻车台' and RegionId>0
		and not exists (select 1 from ArrangeInfo where  ArrangeInfo.WorkDt=@workDt and ArrangeInfo.StaffId=DeviceInfo.Id and ArrangeInfo.TimeType=-999)

	---单警务区未分配到警务区
	insert into ArrangeInfo(StaffId,WorkDt,ShiftType,StaffName,StationId,RegionId,timetype,TimeName,FromTime,totime)
	select a.Id,@workDt,4,a.Name,b.StationId,b.Id,-999,'巡逻车台',
		CAST(convert(char(10),@workDt,120)+' 08:00:00' as datetime),
		CAST(convert(char(10),DATEADD(d,1,@workDt),120)+' 08:00:00' as datetime)
	from DeviceInfo a, SubRegion b 
	where a.[Type]='巡逻车台' and a.StationId=b.StationId
		and not exists (select 1 from ArrangeInfo where  ArrangeInfo.WorkDt=@workDt and ArrangeInfo.StaffId=a.Id and ArrangeInfo.TimeType=-999)
		and b.StationId in (select StationId from SubRegion group by StationId having count(StationId)=1)
END
GO

