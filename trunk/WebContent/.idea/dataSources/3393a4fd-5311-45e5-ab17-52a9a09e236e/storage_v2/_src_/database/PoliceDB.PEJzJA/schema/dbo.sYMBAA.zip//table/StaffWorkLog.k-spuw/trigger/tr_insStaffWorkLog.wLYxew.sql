-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tr_insStaffWorkLog]
   ON [dbo].[StaffWorkLog]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
update staff set State=inserted.State,ServiceId=inserted.Id
	from inserted
	where inserted.state in('ll0','自接')
	and inserted.staffId=staff.Id
	
    -- Insert statements for trigger here

END
GO

