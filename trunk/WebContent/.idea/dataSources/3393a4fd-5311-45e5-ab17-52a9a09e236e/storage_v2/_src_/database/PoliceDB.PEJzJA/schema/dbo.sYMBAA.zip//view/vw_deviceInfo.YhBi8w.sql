CREATE VIEW [dbo].[vw_deviceInfo]
AS
SELECT     '1' AS DevTab,DeviceInfo.Id,DeviceInfo.Name, [Type], [VideoType], [StationId], [Param], DeviceInfo.[Code], [State], [RegionId], [ShiftType], [Longitude], [Latitude], [Address], [LastPosTime], 
                      [ServiceId], [staff_code], [Remark], [IsUse], [UserName], CASE Type WHEN '巡逻车台' THEN DeviceInfo.Id ELSE UserId END AS UserId, 
                      CASE Type WHEN '巡逻车台' THEN 2 ELSE 3 END AS BindType, [DeviceState], [DeviceLogId], [UpdateDt], [PrevX], [PrevY], [PrePosTime],Manufacturer VideoIds
                      ,basedict.name AssembleType
FROM        DeviceInfo  
left outer join BaseDict
on DeviceInfo.assembletype=BaseDict.Code 
where BaseDict.DictName='AssembleType'
GO

