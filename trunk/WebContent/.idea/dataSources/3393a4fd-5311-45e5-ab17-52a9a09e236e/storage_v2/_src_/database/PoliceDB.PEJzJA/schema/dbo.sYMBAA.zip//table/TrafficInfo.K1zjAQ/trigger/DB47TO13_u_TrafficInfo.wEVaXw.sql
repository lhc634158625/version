/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_u_TrafficInfo] 
   ON  [dbo].[TrafficInfo]
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;	
    declare @Remark nvarchar(MAX)
    set @Remark= ''
    
    if update([FromX]) BEGIN SET @Remark = @Remark +'FromX,' END
      if update([FromY]) BEGIN SET @Remark = @Remark +'FromY,' END
      if update([ToX]) BEGIN SET @Remark = @Remark +'ToX,' END
      if update([ToY]) BEGIN SET @Remark = @Remark +'ToY,' END
      if update([Speed]) BEGIN SET @Remark = @Remark +'Speed,' END
      if update([RoadType]) BEGIN SET @Remark = @Remark +'RoadType,' END
      if update([RoadId]) BEGIN SET @Remark = @Remark +'RoadId,' END
      if update([CheckStatus]) BEGIN SET @Remark = @Remark +'CheckStatus,' END
      if update([Checker]) BEGIN SET @Remark = @Remark +'Checker,' END
      if update([CheckDt]) BEGIN SET @Remark = @Remark +'CheckDt,' END
      if update([UpdatedDt]) BEGIN SET @Remark = @Remark +'UpdatedDt,' END
      if update([BusSpeed]) BEGIN SET @Remark = @Remark +'BusSpeed,' END     
      if update([SpeedRoadId]) BEGIN SET @Remark = @Remark +'SpeedRoadId,' END
      if update([Direct]) BEGIN SET @Remark = @Remark +'Direct,' END
      if update([Angle]) BEGIN SET @Remark = @Remark +'Angle,' END  
      if update([EndDt_Bus]) BEGIN SET @Remark = @Remark +'EndDt_Bus,' END
      if update([EndDt_Taxi]) BEGIN SET @Remark = @Remark +'EndDt_Taxi,' END  

    if @Remark !=''
    BEGIN
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey],[Fields])
    select 'DB47TO13' ,'dbo'  ,'TrafficInfo' ,'EdgeId=' + convert(varchar(50),inserted.EdgeId),'U',0, 'UDB47TO13dboTrafficInfoEdgeId=' + convert(varchar(50),inserted.EdgeId),@Remark
    from inserted
    End
END
GO

