/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_i_ShiftTime] 
   ON  [dbo].[ShiftTime]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO13' ,'dbo'  ,'ShiftTime' ,'Id=' + convert(varchar(50),inserted.Id) ,'I',0, 'IDB47TO13dboShiftTimeId=' + convert(varchar(50),inserted.Id) 
    from inserted
END
GO

