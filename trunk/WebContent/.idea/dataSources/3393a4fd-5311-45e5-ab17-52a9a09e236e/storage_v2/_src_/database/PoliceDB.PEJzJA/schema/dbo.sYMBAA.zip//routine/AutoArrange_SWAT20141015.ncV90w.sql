

CREATE PROCEDURE [dbo].[AutoArrange_SWAT20141015] 
	(@workDt Date, @updater int)
AS
BEGIN
	declare @count int
	select @count = COUNT(*) from SWATHis where WorkDt=@workDt
	---print @count
	if @count>0 return	
	declare @copyWorkDt date
	select @copyWorkDt = MAX(WorkDt) from SWATHis where WorkDt<@workDt
	if @copyWorkDt = null return
	declare @dayDiff int
	set @dayDiff = datediff(d,@copyWorkDt,@workDt)
	
	insert SWATHis([SWATID]
      ,[Name]
      ,[PatrolArea]
      ,[Memo]
      ,[Longitude]
      ,[Latitude]
      ,[PoliceCode]
      ,[LeaderName]
      ,[LeaderPost]
      ,[LeaderPhone]
      ,[PoliceCode_1]
      ,[LeaderName_1]
      ,[LeaderPost_1]
      ,[LeaderPhone_1]
      ,[RadioGroup]
      ,[RadioFrequency]
      ,[RadioNo]
      ,[CarNo]
      ,[DutyNumber]
      ,[DutyNumber_1]
      ,[FromTime]
      ,[ToTime]
      ,[WeaponryPike]
      ,[WeaponryPistols]
      ,[RiotDogNumber]
      ,[WorkDt]
      ,[Updater]
      ,[UpdateDt]
      ,[Created])
	select [SWATID]
      ,[Name]
      ,[PatrolArea]
      ,[Memo]
      ,[Longitude]
      ,[Latitude]
      ,[PoliceCode]
      ,[LeaderName]
      ,[LeaderPost]
      ,[LeaderPhone]
      ,[PoliceCode_1]
      ,[LeaderName_1]
      ,[LeaderPost_1]
      ,[LeaderPhone_1]
      ,[RadioGroup]
      ,[RadioFrequency]
      ,[RadioNo]
      ,[CarNo]
      ,[DutyNumber]
      ,[DutyNumber_1]
      ,DATEADD(DAY, @dayDiff, [FromTime])
      ,DATEADD(DAY, @dayDiff, [ToTime])
      ,[WeaponryPike]
      ,[WeaponryPistols]
      ,[RiotDogNumber]
      ,@workDt
      ,@updater
      ,GETDATE()
      ,GETDATE()
	from SWATHis where WorkDt=@copyWorkDt and exists (select 1 from PointInfo where SWATHis.SWATID=PointInfo.Id and PointInfo.[State]='启用')
		
END


GO

