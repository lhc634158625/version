CREATE PROCEDURE [dbo].[GetTrafficPoint]	
	@filter varchar(800)
AS
BEGIN
declare @sqlstr varchar(MAX)
set @sqlstr='select Id,Name,a.RC,Longitude,Latitude from TrafficPoint,(select WFDZ,COUNT(Id) RC from trafficviolation where XZQH in (''350203'',''350206'')	'
set @sqlstr+=@filter
set @sqlstr += ' group by wfdz	) a	where a.WFDZ=name 	order by rc desc'
exec (@sqlstr)
END
GO

