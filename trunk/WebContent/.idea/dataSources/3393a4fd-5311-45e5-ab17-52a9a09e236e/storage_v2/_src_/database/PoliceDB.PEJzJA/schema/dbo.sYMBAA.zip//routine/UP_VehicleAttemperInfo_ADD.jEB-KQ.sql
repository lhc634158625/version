-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UP_VehicleAttemperInfo_ADD] 
	-- Add the parameters for the stored procedure here
	@userId int, 
	@deviceId int,
	@content nvarchar(70)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @result int;

    -- Insert statements for procedure here
	exec @result=[GPSCENTER].[TXServer].[dbo].UP_VehicleAttemperInfo_ADD @userId,@deviceId,@content
	print @result
END
GO

