/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO132_i_InterceptArrange] 
   ON  [dbo].[InterceptArrange]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO132' ,'dbo'  ,'InterceptArrange' ,'Id=' + convert(varchar(50),inserted.Id) ,'I',0, 'IDB47TO132dboInterceptArrangeId=' + convert(varchar(50),inserted.Id) 
    from inserted
END
GO

