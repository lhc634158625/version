Create PROCEDURE [dbo].[CopySWATHis] 
	(@fromDt Date, @toDt Date, @ownerTypes nvarchar(100), @stationIds varchar(500), @updater int)
AS
BEGIN
	if @fromDt=@toDt return 0
	declare @returnValue int
	declare @sql varchar(4000)
	declare @dayDiff varchar(10)
	set @dayDiff = datediff(d,@fromDt,@toDt)
	
	set @sql='insert SWATHis([SWATID],[Name],[PatrolArea],[Memo],[Longitude],[Latitude],[PoliceCode],[LeaderName],[LeaderPost]
      ,[LeaderPhone],[PoliceCode_1],[LeaderName_1],[LeaderPost_1],[LeaderPhone_1],[RadioGroup],[RadioFrequency]
      ,[RadioNo],[CarNo],[DutyNumber],[DutyNumber_1],[FromTime],[ToTime],[WeaponryPike],[WeaponryPistols],[RiotDogNumber]
      ,[WorkDt],[Updater],[UpdateDt],[Created],[BriefResults],[Creater],[CreaterStation],[StationIds],[StationNames])
	select [SWATID],[Name],[PatrolArea],[Memo],[Longitude],[Latitude],[PoliceCode],[LeaderName],[LeaderPost]
      ,[LeaderPhone],[PoliceCode_1],[LeaderName_1],[LeaderPost_1],[LeaderPhone_1],[RadioGroup],[RadioFrequency]
      ,[RadioNo],[CarNo],[DutyNumber],[DutyNumber_1],DATEADD(DAY, '+@dayDiff+', [FromTime]),DATEADD(DAY, '+@dayDiff+', [ToTime]),[WeaponryPike],[WeaponryPistols],[RiotDogNumber]
      ,'''+convert(varchar(10),@toDt)+''','+Convert(varchar(10),@updater)+',GETDATE(),GETDATE(),null,[Creater],[CreaterStation],[StationIds],[StationNames]
	from SWATHis where WorkDt='''+convert(varchar(10),@fromDt)
		+'''and SWATID in (select Id from PointInfo where OwnerType in ('+@ownerTypes+') and [State]=''启用'')
		and SUBSTRING(CreaterStation,0,CHARINDEX(''_'', CreaterStation)) in ('+@stationIds 
		+') and SWATID not in (select SWATID from SWATHis where WorkDt='''+convert(varchar(10),@toDt)+''')'
		
	--print @sql
	
	exec( @sql)
	--return 1
	return @@ROWCOUNT	
END
GO

