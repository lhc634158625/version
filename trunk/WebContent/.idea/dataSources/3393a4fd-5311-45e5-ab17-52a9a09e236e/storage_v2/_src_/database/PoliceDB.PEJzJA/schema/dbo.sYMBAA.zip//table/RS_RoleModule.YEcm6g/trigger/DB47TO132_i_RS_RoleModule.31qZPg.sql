/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO132_i_RS_RoleModule] 
   ON  [dbo].[RS_RoleModule]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO132' ,'dbo'  ,'RS_RoleModule' ,'Id=' + convert(varchar(50),inserted.Id) ,'I',0, 'I+DB47TO132+dbo+RS_RoleModule+Id=' + convert(varchar(50),inserted.Id) 
    from inserted
END
GO

