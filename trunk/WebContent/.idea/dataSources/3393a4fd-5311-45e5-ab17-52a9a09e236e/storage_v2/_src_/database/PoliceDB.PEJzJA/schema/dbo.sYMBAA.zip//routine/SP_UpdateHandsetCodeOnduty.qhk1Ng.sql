-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_UpdateHandsetCodeOnduty]

AS
BEGIN
	insert into  [GPSCENTER].[TXServer].[dbo].[Staff2] (
	   [Id]
      ,[Station]
      ,[Region]
      ,[Name]
      ,[Telephone]
      ,[Position]
      ,[Onduty]
      ,[VerhicleId]
      ,[SaveTime]
      )
SELECT [Id]
	  ,[Station]
	  ,[RegionId]
      ,[Name]
      ,[Telephone]
      ,[Position]
      ,case when [State]='备勤' then 0 else 1 end
      ,[DevCode]
      ,GETDATE()
  FROM [PoliceDB].[dbo].[Staff]
  where Station is not null and (IsDel is null or IsDel !=1) and HandsetCode is not null and HandsetCode !=''
  and Id not in (SELECT [Id] FROM [GPSCENTER].[TXServer].[dbo].[Staff2])
 --
  update [GPSCENTER].[TXServer].[dbo].[Staff2] 
  set [Onduty]= (case when a.State ='备勤' then 0 else 1 end), [SaveTime]=GETDATE(), [VerhicleId]=a.HandsetCode
  FROM [GPSCENTER].[TXServer].[dbo].[Staff2] b
  inner join [PoliceDB].[dbo].[Staff] a on a.Id =b.Id
  
  delete [GPSCENTER].[TXServer].[dbo].[Staff2] 
  where [VerhicleId] is null

END
GO

