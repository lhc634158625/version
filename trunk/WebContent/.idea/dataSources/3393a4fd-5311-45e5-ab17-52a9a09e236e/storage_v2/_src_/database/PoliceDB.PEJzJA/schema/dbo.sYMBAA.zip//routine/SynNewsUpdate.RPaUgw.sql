CREATE PROCEDURE [dbo].[SynNewsUpdate]
	
AS
BEGIN
	declare @minDt datetime
	declare @maxDt datetime
	select @minDt=NewsDt from SynDataLog
	declare @sql_from varchar(4000)
	declare @sql varchar(4000)
	set @sql_from = 'select * from [News] where AddDate>DateAdd(day,-2,'''+convert(varchar(20),@minDt,120)+''') 
	and ClassID in (''0711415371460997'',''0711415594566854'',''0711520051856868'',''0711609254173649'',''120502221200001'',''120502221900002'',''135810525862591'',''135809232677818'')'
	set @sql='insert into [News]
	select * from OpenQuery([10.130.201.35], '''+replace(@sql_from,'''','''''')+''') a 
	where not exists (select ID from [News] where [News].ID=a.ID)'
	--print(@sql)
	exec (@sql)
	
	set @sql='delete from [News] where AddDate>DateAdd(day,-2,'''+convert(varchar(20),@minDt,120)+''') 
	and not exists (select 1 from OpenQuery([10.130.201.35], '''+replace(@sql_from,'''','''''')+''') a where a.ID=[News].ID)'
	--eprint(@sql)
	exec (@sql)
	
	select @maxDt=max(AddDate) from [News]	 
	update syndatalog set NewsDt=@maxDt where NewsDt!=@maxDt 
END
GO

