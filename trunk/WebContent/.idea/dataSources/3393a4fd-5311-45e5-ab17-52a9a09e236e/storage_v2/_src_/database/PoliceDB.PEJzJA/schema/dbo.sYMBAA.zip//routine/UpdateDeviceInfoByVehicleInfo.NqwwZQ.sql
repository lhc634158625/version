-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateDeviceInfoByVehicleInfo]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	INSERT INTO [PoliceDB].[dbo].[DeviceInfo]([VideoType],[Name],[Type],[StationId],[Param],[Code],[State],[RegionId])
SELECT [VehicleTypeId],[VehicleLic],
'巡逻车台',
null,
[Mobile],
[VehicleID],
null,
null
  FROM [GPSCENTER].[TXServer].[dbo].[VehicleInfo]
  where convert(varchar(50),[VehicleID]) not in (SELECT [Code]
  FROM [PoliceDB].[dbo].[DeviceInfo])
  and [EnrollType] not in (12,13)
  
  INSERT INTO [PoliceDB].[dbo].[DeviceInfo]([VideoType],[staff_code],[Name],[Type],[StationId],[Param],[Code],[State],[RegionId])
SELECT [VehicleTypeId],[VehicleNum],[VehicleLic],
'单兵电台(单模)',
null,
[Mobile],
[VehicleID],
null,
null
  FROM [GPSCENTER].[TXServer].[dbo].[VehicleInfo]
  where convert(varchar(50),[VehicleID]) not in (SELECT [Code]
  FROM [PoliceDB].[dbo].[DeviceInfo])
  and [EnrollType] =13
  
    INSERT INTO [PoliceDB].[dbo].[DeviceInfo]([VideoType],[staff_code],[Name],[Type],[StationId],[Param],[Code],[State],[RegionId])
SELECT [VehicleTypeId],[VehicleNum],[VehicleLic],
'单兵电台（多模）',
null,
[Mobile],
[VehicleID],
null,
null
  FROM [GPSCENTER].[TXServer].[dbo].[VehicleInfo]
  where convert(varchar(50),[VehicleID]) not in (SELECT [Code]
  FROM [PoliceDB].[dbo].[DeviceInfo])
  and [EnrollType] =12
  
  
  --update Staff  set HandsetCode=d.Code
  --from [PoliceDB].[dbo].[DeviceInfo] d
  --where d.Type!='巡逻车台' and Staff.Code =d.staff_code and d.staff_code is not null and Staff.HandsetCode is null
  
END
GO

