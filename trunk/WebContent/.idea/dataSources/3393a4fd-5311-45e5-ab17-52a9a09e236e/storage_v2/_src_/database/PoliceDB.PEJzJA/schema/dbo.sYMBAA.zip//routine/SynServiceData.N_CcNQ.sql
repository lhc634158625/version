CREATE PROCEDURE [dbo].[SynServiceData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN

	declare @maxDt datetime
	declare @minDt datetime
	declare @sql varchar(4000)
	select @minDt=MaxReceiveDt from SynDataLog
	
		set @sql='select * from DXCPZJB where ACCEPT_UNIT_NAME like ''%警务区'' and  BDATE >sysdate-0.05 ';
		--set @sql='select * from DXCPZJB where ACCEPT_UNIT_NAME like ''%警务区'' and BDATE>=to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'') ';
		--and BDATE>=to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'') 
		set @sql='insert into RegionService(ReceiveDt,Type,RegionId,Memo,serviceid,StationId,reportname,reporttel,reportaddress,Longitude,Latitude,typename,CASE_ID,Ora_LSH,MainEventFlag,ModifyTime,StartTime,AcceptUnitName,Code,FirstTime_UnitName,UpdateDt)
		select a.BDATE,c.CaseTypeIDS,b.Id,a.REMARK,null,b.StationId,a.CALLER_NAME,a.MOBILE,a.ALARM_ADDRESS,
		CASE WHEN (rtrim(a.LON) =''0'' or rtrim(a.LAT) =''0'' or LOCATE_ERR=16000) then  b.CenterX else SUBSTRING(rtrim(a.LON),0,4) + ''.''+SUBSTRING(rtrim(a.LON),4,LEN(a.LON)) end, 
		CASE WHEN (rtrim(a.LON) =''0'' or rtrim(a.LAT) =''0'' or LOCATE_ERR=16000) then  b.CenterY else SUBSTRING(rtrim(a.LAT),0,3) + ''.''+SUBSTRING(rtrim(a.LAT),3,LEN(a.LAT)) end,
		a.case_event_type,a.CASE_ID, a.LSH,a.main_event_flag,a.modify_time,a.starttime,a.accept_unit_name, a.jqh,GETDATE(),GETDATE() from OpenQuery(ORASERVER, '''+replace(@sql,'''','''''')+''') a,
		SubRegion b, CaseType c
		where SUBSTRING(a.ACCEPT_UNIT_NAME,0,4)=b.Name 
		and a.case_event_type=c.CaseType		
		and  not exists (select 1 from RegionService where RegionService.Ora_LSH=a.LSH )';
		exec (@sql)
		
				
		set @sql='select * from DXCPZJB where ACCEPT_UNIT_NAME not like ''%警务区'' and BDATE >sysdate-0.05 ';
		set @sql='insert into RegionService(ReceiveDt,Type,RegionId,Memo,serviceid,StationId,reportname,reporttel,reportaddress,Longitude,Latitude,typename,CASE_ID,Ora_LSH,MainEventFlag,ModifyTime,StartTime,AcceptUnitName,Code,FirstTime_UnitName,UpdateDt)
		select a.BDATE,c.CaseTypeIDS,0,a.REMARK,null,b.StationId,a.CALLER_NAME,a.MOBILE,a.ALARM_ADDRESS,
		CASE WHEN (rtrim(a.LON) =''0'' or rtrim(a.LAT) =''0'' or LOCATE_ERR=16000) then  d.CenterX else SUBSTRING(rtrim(a.LON),0,4) + ''.''+SUBSTRING(rtrim(a.LON),4,LEN(a.LON)) end, 
		CASE WHEN (rtrim(a.LON) =''0'' or rtrim(a.LAT) =''0'' or LOCATE_ERR=16000) then  d.CenterY else SUBSTRING(rtrim(a.LAT),0,3) + ''.''+SUBSTRING(rtrim(a.LAT),3,LEN(a.LAT)) end,
		a.case_event_type,a.CASE_ID,a.LSH,a.main_event_flag,a.modify_time,a.starttime,a.accept_unit_name, a.jqh,GETDATE(),GETDATE() from OpenQuery(ORASERVER, '''+replace(@sql,'''','''''')+''') a,
		TempUnits b, CaseType c, Station d
		where a.ACCEPT_UNIT_NAME=b.UnitName 
		and a.case_event_type=c.CaseType
		and b.StationId=d.Id
		and  not exists (select 1 from RegionService where RegionService.Ora_LSH=a.LSH )';
		exec (@sql)
		
	--	set @sql='select * from DXCPZJB where (ACCEPT_UNIT_NAME is null or ACCEPT_UNIT_NAME='''') and BDATE >sysdate-0.05';
	--	set @sql='insert into RegionService(ReceiveDt,Type,RegionId,Memo,serviceid,StationId,reportname,reporttel,reportaddress,Longitude,Latitude,typename,CASE_ID,Ora_LSH,MainEventFlag,ModifyTime,starttime,AcceptUnitName)
	--	select a.BDATE,c.CaseTypeIDS,0,a.REMARK,null,743,a.CALLER_NAME,a.MOBILE,a.ALARM_ADDRESS,
	--	CASE WHEN (rtrim(a.LON) =''0'' or rtrim(a.LAT) =''0'' or LOCATE_ERR=16000) then  d.CenterX else SUBSTRING(rtrim(a.LON),0,4) + ''.''+SUBSTRING(rtrim(a.LON),4,LEN(a.LON)) end, 
	--	CASE WHEN (rtrim(a.LON) =''0'' or rtrim(a.LAT) =''0'' or LOCATE_ERR=16000) then  d.CenterY else SUBSTRING(rtrim(a.LAT),0,3) + ''.''+SUBSTRING(rtrim(a.LAT),3,LEN(a.LAT)) end,
	--	a.case_event_type,a.CASE_ID,a.LSH,a.main_event_flag,a.modify_time,a.starttime,a.accept_unit_name from OpenQuery(ORASERVER, '''+replace(@sql,'''','''''')+''') a,
	--	CaseType c, station d
	--	where a.case_event_type=c.CaseType and d.id=743		
	--	and  not exists (select 1 from RegionService where RegionService.Ora_LSH=a.LSH )';
	--	exec (@sql)	
		
		
	select @maxDt=max(ReceiveDt) from RegionService	
	update syndatalog set MaxReceiveDt=@maxDt

	
	--select @maxDt=MaxReceiveDt from SynDataLog	
	--同步到gps数据库
	--exec [SP_PushToGPS] @minDt,@maxDt	
	
END
GO

