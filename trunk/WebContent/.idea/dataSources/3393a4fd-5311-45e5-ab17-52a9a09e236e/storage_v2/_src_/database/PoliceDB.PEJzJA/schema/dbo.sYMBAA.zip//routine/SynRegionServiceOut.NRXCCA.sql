CREATE PROCEDURE [dbo].[SynRegionServiceOut]
AS
BEGIN 
	DECLARE @maxId int
	DECLARE @minId int
	SELECT @minId=[ORegionServiceId] from [DataMigrationParam]
	SELECT @maxId=MAX([Id]) FROM [RegionService]
	IF @maxId>(@minId+1000) 
	BEGIN
	SET @maxId = @minId+1000
	END
	
	--BEGIN TRAN mytran
	---插入目标
	INSERT INTO [100.168.60.35].[TempPolice].[dbo].[RegionService](
		  [Id]
		  ,[RegionId]
		  ,[ServiceId]
		  ,[ServiceState]
		  ,[ReceiveDt]
		  ,[Type]
		  ,[Memo]
		  ,[StationId]
		  ,[ProcessDt]
		  ,[ReportName]
		  ,[ReportTel]
		  ,[ReportAddress]
		  ,[Longitude]
		  ,[Latitude]
		  ,[TypeName]
		  ,[Result]
		  ,[JCJId]
		  ,[CASE_ID]
		  ,[FKSC]
		  ,[Ora_LSH]
		  ,[MainEventFlag]
		  ,[ModifyTime]
		  ,[StartTime]
		  ,[AcceptUnitName]
		  ,[AcceptUnitSubRegion]
		  ,[Code])
	SELECT [Id]
		  ,[RegionId]
		  ,[ServiceId]
		  ,[ServiceState]
		  ,[ReceiveDt]
		  ,[Type]
		  ,[Memo]
		  ,[StationId]
		  ,[ProcessDt]
		  ,[ReportName]
		  ,[ReportTel]
		  ,[ReportAddress]
		  ,[Longitude]
		  ,[Latitude]
		  ,[TypeName]
		  ,[Result]
		  ,[JCJId]
		  ,[CASE_ID]
		  ,[FKSC]
		  ,[Ora_LSH]
		  ,[MainEventFlag]
		  ,[ModifyTime]
		  ,[StartTime]
		  ,[AcceptUnitName]
		  ,[AcceptUnitSubRegion]
		  ,[Code]
	  FROM [RegionService]
	  WHERE [Id] > @minId AND [Id] < @maxId

	---更新参数表
	UPDATE [DataMigrationParam] SET [ORegionServiceId]=@maxId
	/*	
	IF @@ERROR<>0 
	BEGIN
		ROLLBACK TRAN mytran
	END
	ELSE
	BEGIN
		COMMIT TRAN mytran
	END	  
	---结束事物
	*/
END

GO

