CREATE VIEW dbo.VTShiftType
AS
WITH cteShiftType AS (SELECT  Id, PId, Name, CAST(Name AS nvarchar(MAX)) AS NamePath, CAST(Id AS nvarchar(MAX)) 
                                                                AS IdPath, 1 AS TLevel
                                             FROM       dbo.ShiftType
                                             WHERE    (PId IS NULL)
                                             UNION ALL
                                             SELECT  c.Id, c.PId, c.Name, p.NamePath + ',' + c.Name AS NamePath, CAST(c.Id AS nvarchar(MAX)) 
                                                                + ',' + CAST(p.IdPath AS nvarchar(MAX)) AS IdPath, p.TLevel + 1 AS TLevel
                                             FROM      cteShiftType AS p INNER JOIN
                                                                dbo.ShiftType AS c ON p.Id = c.PId)
    SELECT  Id, PId, Name, NamePath, IdPath, TLevel
    FROM      cteShiftType AS c
GO

