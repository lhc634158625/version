CREATE trigger [dbo].[TR_CaseInfo_Update]
on dbo.CaseInfo
after update
as
begin
	if update ([StationCode])--当字段被更新时，才会触发此触发器
	update CaseInfo set Created=GETDATE(),UpdateTime=GETDATE() from CaseInfo c,inserted i,deleted d
	where i.CASECODE=c.CASECODE 
	and i.CASECODE=d.CASECODE
	and i.StationCode<>d.StationCode
end
GO

DISABLE TRIGGER TR_CaseInfo_Update ON CaseInfo
GO

