CREATE PROCEDURE [dbo].[SynVio_ViolationData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	declare @count int
	declare @count1 int
	declare @maxDt datetime
	declare @minDt datetime
	declare @sql varchar(4000)
	
	select @minDt=isnull(Vio_ViolationTime,'2014-01-01') from SynDataLog
	select @count= COUNT(*) from TrafficViolation
	set @maxDt = DATEADD(MINUTE, 3 * 60,@minDt)
	
		set @sql='SELECT * FROM "TRFF_APP"."VIO_VIOLATION" ';
		set @sql = @sql + 'WHERE  GXSJ >= TO_DATE('''+convert(varchar(20),@minDt,120)+''', ''YYYY-MM-DD HH24:MI:SS'') AND GXSJ <= TO_DATE('''+convert(varchar(20), @maxDt,120)+''', ''YYYY-MM-DD HH24:MI:SS'') AND substr(FXJG,0,4) =''3502'' ORDER BY GXSJ';
		
		Set @sql='INSERT INTO [TrafficViolation]([DSR],[DABH],[DH],[LXFS],[ZSXZQH],[ZSXXDZ],[RYFL],[SYXZ],[HPZL],[HPHM],[JDCSYR],[CLFL],[CLYT],[CFZL],[CLJGMC],[FSJG],[CLSJ],[WFBH],[JBR1],[JBR2],[ZJCX],[JKFS],[WFDZ],[ZQMJ],[FXJG],[JTFS],[SGDJ],[JSJQBJ],[XXLY],[LRSJ],[WFXW],[WFJFS],[FKJE],[JDSLB],[JDSBH],[WSJYW],[PZBH],[JKRQ],[JLLX],[ZDJLBJ],[XRMS],[WFSJ],[WFSJ1],[XZQH],[DLLX],[GLXZDJ],[WFDD],[GXSJ],[LRR],[FZJG],[JSZH],[JKBJ]) 
		select a.DSR,a.DABH,a.DH,a.LXFS,a.ZSXZQH,a.ZSXXDZ,a.RYFL,a.SYXZ,a.HPZL,a.HPHM,a.JDCSYR,a.CLFL,a.CLYT,a.CFZL,a.CLJGMC,a.FSJG,a.CLSJ,a.WFBH,a.JBR1,a.JBR2,a.ZJCX,a.JKFS,a.WFDZ,a.ZQMJ,a.FXJG,a.JTFS,a.SGDJ,a.JSJQBJ,a.XXLY,a.LRSJ,a.WFXW,a.WFJFS,a.FKJE,a.JDSLB,a.JDSBH,a.WSJYW,a.PZBH,a.JKRQ,a.JLLX,a.ZDJLBJ,a.XRMS,a.WFSJ,a.WFSJ1,a.XZQH,a.DLLX,a.GLXZDJ,a.WFDD,a.GXSJ,a.LRR,a.FZJG,a.JSZH,a.JKBJ 
		from OpenQuery(RACDB, '''+replace(@sql,'''','''''')+''') a 
		WHERE not exists (select 1 from TrafficViolation where TrafficViolation.WFBH=a.WFBH )';
		--print(@sql)
		exec (@sql)
	
	select @count1= COUNT(*) from TrafficViolation
	if( @count = @count1 and @maxDt < GETDATE() - 0.1)
	Begin
		update syndatalog set Vio_ViolationTime=@maxDt
	End
	else
	Begin
		select @maxDt=max(GXSJ) from TrafficViolation	
		update syndatalog set Vio_ViolationTime=@maxDt
	end	
	
	
	
END
GO

