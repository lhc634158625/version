/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO132_i_News] 
   ON  [dbo].[News]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO132' ,'dbo'  ,'News' ,'ID=' + convert(varchar(50),inserted.ID) ,'I',0, 'IDB47TO132dboNewsID=' + convert(varchar(50),inserted.ID) 
    from inserted
END
GO

