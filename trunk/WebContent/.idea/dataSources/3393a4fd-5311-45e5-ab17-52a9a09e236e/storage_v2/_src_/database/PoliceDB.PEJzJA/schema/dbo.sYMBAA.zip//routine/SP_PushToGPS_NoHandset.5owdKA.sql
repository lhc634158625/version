
CREATE procedure [dbo].[SP_PushToGPS_NoHandset](@minDt datetime,@maxDt datetime)
as
begin
-- 同步到gps系统
 BEGIN TRY
 insert into [GPSCENTER].[TXServer].[dbo].[ReportToPolice](
      [VehicleID]
      ,[PoliceName]
      ,[Station]
      ,[Region]
      ,[ReportName]
      ,[ReportTele]
      ,[ReportAddress]
      ,[ReportSituation]
      ,SaveTime
      )
select a.DevCode,a.Name,a.Station,a.Region,b.reportName,b.ReportTel,b.ReportAddress,b.Memo,ReceiveDt
 from vw_RegionVerhicleInfo a,RegionService b
 where (a.RegionId=b.RegionId or(b.RegionId=0 and a.StationId=b.StationId))
 and b.ReceiveDt>=@minDt and b.ReceiveDt<@maxDt
END TRY
BEGIN CATCH
   -- SELECT ERROR_LINE() AS ErrorLine;
END CATCH;
end
GO

