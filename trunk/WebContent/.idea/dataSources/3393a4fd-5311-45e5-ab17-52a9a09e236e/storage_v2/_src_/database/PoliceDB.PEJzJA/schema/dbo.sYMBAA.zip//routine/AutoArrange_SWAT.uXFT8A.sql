
CREATE PROCEDURE [dbo].[AutoArrange_SWAT] 
	(@workDt Date, @updater int)
AS
BEGIN
	declare @count int
	select @count = COUNT(*) from SWATHis where WorkDt=@workDt
		and exists (select 1 from PointInfo where SWATHis.SWATID=PointInfo.Id and PointInfo.OwnerType in ('特警支队巡逻点','分局特警队巡逻点'))
	---print @count
	if @count>0 return	
	declare @copyWorkDt date
	select @copyWorkDt = MAX(WorkDt) from SWATHis where WorkDt<@workDt 
		and exists (select 1 from PointInfo where SWATHis.SWATID=PointInfo.Id and PointInfo.OwnerType in ('特警支队巡逻点','分局特警队巡逻点'))
	if @copyWorkDt = null return
	declare @dayDiff int
	set @dayDiff = datediff(d,@copyWorkDt,@workDt)
	
	insert SWATHis([SWATID]
      ,[Name]
      ,[PatrolArea]
      ,[Memo]
      ,[Longitude]
      ,[Latitude]
      ,[PoliceCode]
      ,[LeaderName]
      ,[LeaderPost]
      ,[LeaderPhone]
      ,[PoliceCode_1]
      ,[LeaderName_1]
      ,[LeaderPost_1]
      ,[LeaderPhone_1]
      ,[RadioGroup]
      ,[RadioFrequency]
      ,[RadioNo]
      ,[CarNo]
      ,[DutyNumber]
      ,[DutyNumber_1]
      ,[FromTime]
      ,[ToTime]
      ,[WeaponryPike]
      ,[WeaponryPistols]
      ,[RiotDogNumber]
      ,[WorkDt]
      ,[Updater]
      ,[UpdateDt]
      ,[Created])
	select t1.[SWATID]
      ,t1.[Name]
      ,t1.[PatrolArea]
      ,t1.[Memo]
      ,t1.[Longitude]
      ,t1.[Latitude]
      ,(case t2.OwnerType when '特警支队巡逻点' then null else t1.[PoliceCode] end)
      ,(case t2.OwnerType when '特警支队巡逻点' then null else t1.[LeaderName] end)
      ,(case t2.OwnerType when '特警支队巡逻点' then null else t1.[LeaderPost] end)
      ,(case t2.OwnerType when '特警支队巡逻点' then null else t1.[LeaderPhone] end)
      ,t1.[PoliceCode_1]
      ,t1.[LeaderName_1]
      ,t1.[LeaderPost_1]
      ,t1.[LeaderPhone_1]
      ,t1.[RadioGroup]
      ,t1.[RadioFrequency]
      ,t1.[RadioNo]
      ,t1.[CarNo]
      ,t1.[DutyNumber]
      ,t1.[DutyNumber_1]
      ,DATEADD(DAY, @dayDiff, t1.[FromTime])
      ,DATEADD(DAY, @dayDiff, t1.[ToTime])
      ,t1.[WeaponryPike]
      ,t1.[WeaponryPistols]
      ,t1.[RiotDogNumber]
      ,@workDt
      ,@updater
      ,GETDATE()
      ,GETDATE()
	from SWATHis t1, PointInfo t2 where t1.WorkDt=@copyWorkDt 
	and t1.SWATID=t2.Id and t2.[State]='启用'
	and t2.OwnerType in ('特警支队巡逻点','分局特警队巡逻点')
		
END

GO

