create  function [dbo].[getweek](@date datetime)
returns varchar(50)
as
begin
return convert(varchar(4),@date,120)+case  when len(datename(week,@date))<2 then '0'+datename(week,@date) else datename(week,@date) end

end
GO

