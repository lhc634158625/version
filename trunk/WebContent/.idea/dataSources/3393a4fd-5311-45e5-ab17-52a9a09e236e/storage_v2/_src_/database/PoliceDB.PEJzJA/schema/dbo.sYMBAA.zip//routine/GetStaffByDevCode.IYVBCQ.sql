CREATE FUNCTION [dbo].GetStaffByDevCode
(
	-- Add the parameters for the function here
	@devCode varchar(50)
	
)
RETURNS varchar(50)
AS
BEGIN
declare @staffs varchar(50)
declare @staffId int
set @staffs=''
declare  cur_staff cursor for	select ID from Staff where DevCode=@devcode and State in('ll0','待警')
	 OPEN cur_staff
	 FETCH NEXT FROM cur_staff INTO @staffId 
WHILE (@@FETCH_STATUS = 0)
BEGIN
     
     set @staffs+=cast(@staffid as varchar(10))+','
    FETCH NEXT FROM cur_staff INTO @staffId 
END
CLOSE cur_staff
DEALLOCATE cur_staff

return @staffs

END
GO

