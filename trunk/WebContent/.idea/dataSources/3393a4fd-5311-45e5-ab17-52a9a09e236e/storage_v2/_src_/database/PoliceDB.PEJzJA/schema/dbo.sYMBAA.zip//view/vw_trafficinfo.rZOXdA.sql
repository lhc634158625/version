CREATE view [dbo].[vw_trafficinfo](FromX,FromY,ToX,ToY,Speed,RoadType,EdgeId,RoadId) as
select a.GEO_X/1000000 FromX,a.GEO_Y/1000000 FromY,b.GEO_X/1000000 ToX,b.GEO_Y/1000000 ToY,c.Speed Speed,d.RoadType,d.Kanten_ID,d.SpeedRoadId
from Map_NodeData a,Map_NodeData b,FCD_EdgeSpeedNew c,Map_EdgeData d
where a.KNOTEN_ID=d.Knoten_ID_From and b.KNOTEN_ID=d.Knoten_ID_To
and c.EdgeID=d.Kanten_ID
GO

