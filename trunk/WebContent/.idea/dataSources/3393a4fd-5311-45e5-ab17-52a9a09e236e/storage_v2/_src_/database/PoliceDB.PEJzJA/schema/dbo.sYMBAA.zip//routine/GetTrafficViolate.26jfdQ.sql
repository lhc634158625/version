

CREATE PROCEDURE [dbo].[GetTrafficViolate]
	-- Add the parameters for the stored procedure here
	@fromDt Datetime, 
	@toDt DateTime,
	@type varchar(50)
AS
BEGIN

	select DATEPART(Hour,WFSJ) as Item,COUNT(Id) RC from trafficviolation 
	
	where 
	XZQH like '3502%' -- in ('350201','350206')

	group by DATEPART(Hour,WFSJ)	
	order by Item
END
GO

