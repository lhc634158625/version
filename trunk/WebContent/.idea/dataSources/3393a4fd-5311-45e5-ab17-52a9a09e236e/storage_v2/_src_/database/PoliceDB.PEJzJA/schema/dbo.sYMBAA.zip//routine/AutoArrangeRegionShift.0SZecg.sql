Create PROCEDURE [dbo].[AutoArrangeRegionShift] 
	(@day int,@today Date,@stationId int, @regionId int, @shiftId int)
AS
BEGIN

insert into ArrangeInfo(StaffId,WorkDt,ShiftType,StaffName,StationId,RegionId,timetype,TimeName,FromTime,totime)
select a.StaffId,@today,a.ShiftType,a.StaffName,a.StationId,a.RegionId,a.TimeType,b.Name,
	CAST(convert(char(10),@today,120)+' '+convert(char(8),b.fromtime) as datetime),
	case 
	when b.FromTime>=b.ToTime then
		CAST(convert(char(10), DATEADD(d,1, @today),120)+' '+convert(char(8),b.totime) as datetime)
	else
		CAST(convert(char(10),@today,120)+' '+convert(char(8),b.totime) as datetime)
	end 
from ArrangeInfo a,ShiftTime b
where a.TimeType=b.Id and WorkDt=DATEADD(day, - @day, @today) and a.StationId=@stationId
	and StaffId not in(select StaffId from ArrangeInfo where  WorkDt=@today and StationId=@stationId and ShiftType=@shiftId)
	and b.IsDel=0 and b.RegionId=@regionId and b.ShiftId=@shiftId
END
GO

