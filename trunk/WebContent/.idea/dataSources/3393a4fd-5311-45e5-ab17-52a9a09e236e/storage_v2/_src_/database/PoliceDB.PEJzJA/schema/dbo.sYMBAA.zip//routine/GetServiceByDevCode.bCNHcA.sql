CREATE FUNCTION [dbo].[GetServiceByDevCode]
(
	-- Add the parameters for the function here
	@devCode varchar(50)
	
)
RETURNS int
AS
BEGIN

declare @ServiceId int
declare @devType varchar(50)

select @devType=[Type] from [DeviceInfo] where [Code]=@devCode

if @devType='巡逻车台'
Begin
select @serviceId=[DeviceInfo].[ServiceId] from [DeviceInfo] left join RegionService a on a.Id=[DeviceInfo].ServiceId  
where a.ProcessDt is null and  [DeviceInfo].[Code]=@devCode
return @ServiceId
end

select @serviceId=id from staffworklog where staffid
in(select id from staff where devcode=@devcode and State in('ll0','待警'))
and processdt is null and state in ('ll0','待警')

return @ServiceId

END
GO

