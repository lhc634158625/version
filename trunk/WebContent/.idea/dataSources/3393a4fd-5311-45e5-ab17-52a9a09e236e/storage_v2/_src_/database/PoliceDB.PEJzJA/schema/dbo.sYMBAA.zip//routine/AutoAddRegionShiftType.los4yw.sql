Create PROCEDURE [dbo].[AutoAddRegionShiftType]
	
AS
BEGIN

insert into RegionShiftType(RegionId,ShiftType,StationId,State,ShiftDays,IsDel)
select distinct b.RegionId,b.ShiftId,b.StationId,'待警',0,0 from  PoliceDB..ShiftTime b
where not exists (select 1 from PoliceDB..RegionShiftType a where a.RegionId=b.RegionId and a.ShiftType=b.ShiftId) and b.IsDel=0

END
GO

