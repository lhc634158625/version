
Create PROCEDURE [dbo].[SynHFB]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	declare @maxDt datetime
	declare @minDt datetime
	set @maxDt=GETDATE()	
	set @minDt=DATEADD(DAY,-1,@maxDt)
	
	declare @sql varchar(4000)
	set @sql='select a.jqh CaseCode,a.bjymc Reporter,a.bjyhm ReportTel,a.bjrlxfs ContactTel,b.lsh Code,b.afdz OccurAddress,
		b.bjsj OccurTime,AJLX||''-''||AJXZ||decode(xzfl,null,'''',''-''||XZFL) CaseType,b.bz Description,sxpcs Station,fabw,b.gxsj,b.zasd,b.XQXQ,b.X,b.Y
		from JJXX_YW_JBJBXX a,hfb b
		where 
		a.bjid||a.ajid=b.lsh and  b.gxsj>to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'')'


	set @sql='insert into HFB([CASECODE],[REPORTER],[REPORTTEL],[CONTACTTEL],[CODE],[OCCURADDRESS],[OCCURTIME],[CASETYPE],[DESCRIPTION],[STATION],[FABW],[GXSJ],[CrimeMeans],[RegionName],[Longitude],[Latitude],[StationCode]) 
		select a.*,b.Code
		from OpenQuery(CASESERVER, '''+replace(@sql,'''','''''')+''') a, Station b
		where a.station=b.oldname and NOT EXISTS (SELECT 1 from HFB where HFB.CASECODE=a.CaseCode)'
	--print @sql
	exec (@sql)


	set @sql='select a.jqh CaseCode,a.bjymc Reporter,a.bjyhm ReportTel,a.bjrlxfs ContactTel,b.lsh Code,b.afdz OccurAddress,
		b.bjsj OccurTime,AJLX||''-''||AJXZ||decode(xzfl,null,'''',''-''||XZFL) CaseType,b.bz Description,sxpcs Station,fabw,b.gxsj,b.zasd,b.XQXQ,b.X,b.Y
		from JJXX_YW_JBJBXX a,hfb b
		where a.bjid||a.ajid=b.lsh and  b.gxsj>to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'')'

	set @sql='update HFB set casetype=a.casetype,updatetime=getdate(),fabw=a.fabw, StationCode=b.Code, Station=a.Station, [RegionName]=a.XQXQ, [Longitude]=a.X, [Latitude]=b.Y
		from OpenQuery(CASESERVER, '''+replace(@sql,'''','''''')+''') a, Station b
		where a.station=b.oldname and a.casecode=HFB.CASECODE'
	--print @sql
	exec (@sql)
	
END
GO

