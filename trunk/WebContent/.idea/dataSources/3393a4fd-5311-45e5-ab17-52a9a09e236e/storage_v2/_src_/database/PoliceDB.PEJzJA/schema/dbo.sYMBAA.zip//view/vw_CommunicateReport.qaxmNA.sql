


CREATE view [dbo].[vw_CommunicateReport]
as
select a.SuccessAmount, a.AllAmount, (a.SuccessAmount * 100)/a.AllAmount [SuccessRate], a.Station StationId, Station.Name [StationName], a.RegionId RegionId, SubRegion.Name [RegionName] from
(
select 
	SUM(
		case 
			when state='无人应答'
				then 1
			when state='处警中'
				then 1
			when state='正常接通'
				then 1
			else
				0
	end) SuccessAmount,
	count(id) AllAmount, Station, RegionId
from CommunicateLog
where DATEDIFF(day,Created,GETDATE())=0
group by Station, RegionId
) a 
inner join SystemParam
on (a.SuccessAmount * 100)/a.AllAmount<SystemParam.CommLowRate
inner join Station on a.Station=Station.Id
left join SubRegion on a.RegionId=SubRegion.Id


GO

