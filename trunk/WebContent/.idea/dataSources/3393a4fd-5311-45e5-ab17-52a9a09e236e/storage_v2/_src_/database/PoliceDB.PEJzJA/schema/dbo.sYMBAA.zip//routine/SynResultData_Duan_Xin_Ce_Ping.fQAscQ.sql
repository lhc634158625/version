
-- =============================================
CREATE PROCEDURE [dbo].[SynResultData_短信测评]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN

	declare @maxid varchar(50)
	declare @minid varchar(50)
	select @minid=ResultId from syndatalog
	select @maxid=MAX(lsh) from [SMSERVIVER].[sms].[dbo].[短信测评]
	
	update RegionService set result=a.myd1
	from [SMSERVIVER].[sms].[dbo].[短信测评] a
	where a.lsh>@minid and a.lsh<=@maxid and a.flag is not null
	and a.lsh=RegionService.ServiceId
	
	update syndatalog set resultId=@maxid
	
END
GO

