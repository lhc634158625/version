CREATE FUNCTION  [dbo].[GetOldCode]
(
	
	
	@code varchar(50)
	
)
RETURNS varchar(50)
AS
BEGIN
 declare @ret varchar(50)
 declare @pos int
 if(@code is null) return null
 set @pos=charindex('#',@code,1)
 if(@pos>0)
	set @ret=SUBSTRING(@code,1,@pos -1)
 else
   set @ret=@code
 return @ret
END
GO

