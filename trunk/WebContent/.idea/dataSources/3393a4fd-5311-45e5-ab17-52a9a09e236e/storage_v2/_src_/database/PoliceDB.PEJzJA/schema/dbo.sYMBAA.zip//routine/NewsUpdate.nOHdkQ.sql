CREATE PROCEDURE [dbo].[NewsUpdate]
	
AS
BEGIN
	insert into [News]
	select * from [10.130.201.35].[xmweb].[dbo].[News] a
		where ClassID in ('0711415371460997','0711415594566854','0711520051856868','0711609254173649','120502221200001','120502221900002','135810525862591','135809232677818')
		and AddDate>'2012-04-01' and not exists (select ID from [News] where [News].ID=a.id)
END
GO

