
create procedure sp_refreshCameraEdge
as
begin
declare  cur_camera cursor for select gisid from CameraInfo where DeviceType='01'
declare @gisid varchar(50)
open cur_camera 

fetch  NEXT FROM cur_camera into @gisid
  while @@FETCH_STATUS=0
  begin
  insert into CameraEdge(GISID,FromX,FromY,ToX,ToY,EdgeId)
   
  select @gisid,FromX,FromY,ToX,ToY,EdgeId from trafficinfo where speedroadid in(
  (select SpeedRoadId from CameraEdge,TrafficInfo   where GISID=@gisid and CameraEdge.EdgeId=TrafficInfo.EdgeId))
  and EdgeId not in(select EdgeId from CameraEdge where GISID=@gisid)
  
 fetch  NEXT FROM cur_camera into @gisid
  end
  close cur_camera
  deallocate cur_camera
  end
GO

