
CREATE procedure [dbo].[sp_AddTVPointEdge] (@masterId int, @lon float, @lat float)
  as
  begin

  declare @edgeid int
  select top 1 @edgeid=EdgeId from 
  (
 select EdgeId,FromX,FromY,ToX,ToY,dbo.p2ldistance(FromX,FromY,ToX,ToY,@lon,@lat) dist from TrafficInfo where abs(FromX-@lon)<0.05 and ABS(fromy-@lat)<0.05
 and abs(tox-@lon)<0.05 and ABS(ToY-@lat)<0.05) a
 order by dist
 print @edgeid
  insert into TVEdge(masterId,edgeid,FromX,FromY,ToX,ToY)
  select @masterid,EdgeId,FromX,FromY,ToX,ToY from TrafficInfo
  where EdgeId=@edgeid and EdgeId not in(select edgeid from TVEdge where masterid=@masterId)

  end

GO

