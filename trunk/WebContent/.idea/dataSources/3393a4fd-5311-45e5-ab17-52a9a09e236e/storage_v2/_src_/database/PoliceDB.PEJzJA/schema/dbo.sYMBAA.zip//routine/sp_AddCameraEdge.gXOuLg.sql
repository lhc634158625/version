CREATE procedure [dbo].[sp_AddCameraEdge] (@gisid varchar(50), @lon float, @lat float)
  as
  begin

  declare @edgeid int
  select top 1 @edgeid=kanten_id from 
  (
 select kanten_id,FromX,FromY,ToX,ToY,dbo.p2ldistance(FromX,FromY,ToX,ToY,@lon,@lat) dist from map_edgedata where abs(FromX-@lon)<0.05 and ABS(fromy-@lat)<0.05
 and abs(tox-@lon)<0.05 and ABS(ToY-@lat)<0.05) a
 order by dist
 print @edgeid
  insert into cameraedge(gisid,edgeid,FromX,FromY,ToX,ToY)
  select @gisid,kanten_id,FromX,FromY,ToX,ToY from map_edgedata
  where kanten_id=@edgeid and kanten_id not in(select edgeid from CameraEdge where gisid=@gisid)

  end
GO

