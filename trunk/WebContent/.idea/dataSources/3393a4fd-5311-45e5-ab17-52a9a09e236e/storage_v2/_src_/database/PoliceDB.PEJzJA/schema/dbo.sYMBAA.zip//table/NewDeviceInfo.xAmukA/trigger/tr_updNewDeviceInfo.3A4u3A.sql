create TRIGGER  [dbo].[tr_updNewDeviceInfo]
   ON  [dbo].[NewDeviceInfo]
   AFTER update
AS 
BEGIN

SET NOCOUNT ON;
	update deviceinfo set stationid=a.stationId,Manufacturer=a.videoid,remark=a.assemblingcode,name=a.name,assembletype=a.assemblingtype,assemblecode=a.assemblingcode
	
	 from (
	 select  dbo.getoldcode(a.code) code, station.id stationid,videoid,assemblingcode,a.name,assemblingtype from inserted a,Station where Station.SCode=a.userCode  and station.isuse=1 and station.id in(select stationid from stationgroup where groupid=5)) a
	 where deviceinfo.code=a.code
END
GO

