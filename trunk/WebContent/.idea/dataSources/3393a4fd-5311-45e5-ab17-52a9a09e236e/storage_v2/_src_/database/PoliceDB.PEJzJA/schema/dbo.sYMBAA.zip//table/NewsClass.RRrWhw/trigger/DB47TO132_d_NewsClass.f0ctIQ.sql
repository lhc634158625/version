/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO132_d_NewsClass] 
   ON  [dbo].[NewsClass]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO132' ,'dbo'  ,'NewsClass' ,'ID=' + convert(varchar(50),deleted.ID),'D',0,'DDB47TO132dboNewsClassID=' + convert(varchar(50),deleted.ID) 
    from deleted
END
GO

