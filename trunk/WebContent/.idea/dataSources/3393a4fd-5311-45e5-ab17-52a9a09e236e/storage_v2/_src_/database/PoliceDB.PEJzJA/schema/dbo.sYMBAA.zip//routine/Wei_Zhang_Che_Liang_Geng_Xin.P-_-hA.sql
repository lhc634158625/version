-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[违章车辆更新]
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	declare @maxid varchar(50)
	declare @minid varchar(50)
	select @minid=[WZId] from syndatalog
	select @maxid=MAX(wz.id) from [100.168.10.88].[new110].[dbo].[违章车辆] wz

	insert into [违章车辆]
           ([时间]
           ,[违章时间]
           ,[车型]
           ,[车牌号码]
           ,[省份简称]
           ,[发证机关]
           ,[牌号]
           ,[车牌后缀]
           ,[车牌颜色]
           ,[CCD]
           ,[地点]
           ,[违章情节]
           ,[登录人]
           ,[台号]
           ,[车主]
           ,[类型代码]
           ,[地方车辆]
           ,[详细地点]
           ,[违章地归类]
           ,[注销人]
           ,[注销日期]
           ,[注销原因]
           ,[图片1]
           ,[图片2]
           ,[图片3]
           ,[上传标志]
           ,[审核标志]
           ,[入库标志]
           ,[上传时间]
           ,[审核修改标志]
           ,[审核人]
           ,[道路代码]
           ,[道路名称])
	select wz.[时间]
           ,wz.[违章时间]
           ,wz.[车型]
           ,wz.[车牌号码]
           ,wz.[省份简称]
           ,wz.[发证机关]
           ,wz.[牌号]
           ,wz.[车牌后缀]
           ,wz.[车牌颜色]
           ,wz.[CCD]
           ,wz.[地点]
           ,wz.[违章情节]
           ,wz.[登录人]
           ,wz.[台号]
           ,wz.[车主]
           ,wz.[类型代码]
           ,wz.[地方车辆]
           ,wz.[详细地点]
           ,wz.[违章地归类]
           ,wz.[注销人]
           ,wz.[注销日期]
           ,wz.[注销原因]
           ,wz.[图片1]
           ,wz.[图片2]
           ,wz.[图片3]
           ,wz.[上传标志]
           ,wz.[审核标志]
           ,wz.[入库标志]
           ,wz.[上传时间]
           ,wz.[审核修改标志]
           ,wz.[审核人]
           ,wz.[道路代码]
           ,wz.[道路名称] 	
	 from [100.168.10.88].[new110].[dbo].[违章车辆] wz
	 where wz.[时间]>'2012-04-01'  and wz.[id] >@minid and wz.[id] <= @maxid 
	 
	 --
	 update syndatalog set [WZId]=@maxid
END
GO

