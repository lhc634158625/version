/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO132_i_BBSInfo] 
   ON  [dbo].[BBSInfo]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO132' ,'dbo'  ,'BBSInfo' ,'Id=' + convert(varchar(50),inserted.Id) ,'I',0, 'IDB47TO132dboBBSInfoId=' + convert(varchar(50),inserted.Id) 
    from inserted
END
GO

