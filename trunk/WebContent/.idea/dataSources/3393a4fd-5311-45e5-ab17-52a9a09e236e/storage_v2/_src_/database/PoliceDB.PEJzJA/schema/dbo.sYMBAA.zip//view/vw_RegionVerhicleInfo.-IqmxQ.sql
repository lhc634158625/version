



     CREATE view [dbo].[vw_RegionVerhicleInfo](Name,DevCode,Station,Region,StationId,RegionId)
     as 
     select a.Name,a.Code,b.Name,c.Name,b.id,c.id
     from DeviceInfo a,Station b,SubRegion c
     where a.StationId=b.Id and a.RegionId=c.Id
     and a.Type='巡逻车台' and LEN(a.Code)=10


     GO

