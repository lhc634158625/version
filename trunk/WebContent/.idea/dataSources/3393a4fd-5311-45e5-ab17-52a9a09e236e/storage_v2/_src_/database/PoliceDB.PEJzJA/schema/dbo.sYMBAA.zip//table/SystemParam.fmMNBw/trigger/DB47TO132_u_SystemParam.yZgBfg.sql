/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [DB47TO132_u_SystemParam] 
   ON  [dbo].[SystemParam]
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;	
    declare @Remark nvarchar(MAX)
    set @Remark= ''
    
set @Remark='NULL'    

    if @Remark !=''
    BEGIN
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey],[Fields])
    select 'DB47TO132' ,'dbo'  ,'SystemParam' ,'Id=' + convert(varchar(50),inserted.Id),'U',0, 'U+DB47TO132+dbo+SystemParam+Id=' + convert(varchar(50),inserted.Id),@Remark
    from inserted
    End
END
GO

