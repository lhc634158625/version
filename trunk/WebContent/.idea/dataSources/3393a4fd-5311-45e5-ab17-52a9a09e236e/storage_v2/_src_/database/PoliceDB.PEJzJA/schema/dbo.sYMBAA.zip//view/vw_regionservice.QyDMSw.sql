



CREATE view [dbo].[vw_regionservice](RegionId,StationId,ReceiveDt,Type,Memo,ShiftType,ProcessDt) as
select regionid,max(StationId),receivedt,max(typename),max(cast(memo as varchar(2000))),shifttype,MAX(processdt)
from staffworklog with (readpast)
group by regionid,shifttype,receivedt
union
select regionid,stationid,receivedt,typename,memo,4,processdt
from regionservice with (readpast)


GO

