CREATE PROCEDURE [dbo].[SynNewsUpdate_MySql]
	
AS
BEGIN
/*
警情通报	61	0711415371460997	jqtb	警情通报
0711415594566854	jjxw	视频检查
0711520051856868	ajfx	110巡防指令
治安摘报	11	0711609254173649	mrqk	每日摘报
120502221200001	XLJC	治安防控竞赛
120502221900002	CQQK	查勤情况
135809232677818	GZGF	工作规范
135810525862591	JCJPJ	接处警评价
*/

	declare @sql_from varchar(4000)
	declare @sql varchar(4000)
	set @sql_from = 'select t1.id,t1.classid,t1.onclick,rtrim(t1.title) title,from_unixtime(newstime) newstime,t2.newstext from phome_ecms_news t1,phome_ecms_news_data_1 t2 where t1.id=t2.id and t1.lastdotime>(unix_timestamp()-86400) 
	and t1.classid in (11,61)'
	set @sql='insert into [News](ID,NewsID,Title,ClassId,Content,AddDate,ClickNum,NClassId)
	select a.id,''FromMySql'',a.title,case a.classid when 11 then ''0711609254173649'' when 61 then ''0711415371460997'' end,a.newstext,a.newstime,a.onclick,a.classid from OpenQuery([NEWSMYSQL], '''+replace(@sql_from,'''','''''')+''') a 
	where not exists (select ID from [News] where [News].ID=a.id)'
	print(@sql)
	exec (@sql)
	
	set @sql_from = 'select t1.id,t1.classid,t1.onclick,rtrim(t1.title) title,from_unixtime(newstime) newstime,t2.newstext from phome_ecms_news t1,phome_ecms_news_data_1 t2 where t1.id=t2.id and t1.lastdotime>(unix_timestamp()-286400) 
	and t1.classid in (11,61)'
	set @sql='delete from [News] where AddDate>DateAdd(day,-2,GETDATE()) and ID>0
	and not exists (select 1 from OpenQuery([NEWSMYSQL], '''+replace(@sql_from,'''','''''')+''') a where a.Id=[News].ID)'
	print(@sql)
	exec (@sql)

END
GO

