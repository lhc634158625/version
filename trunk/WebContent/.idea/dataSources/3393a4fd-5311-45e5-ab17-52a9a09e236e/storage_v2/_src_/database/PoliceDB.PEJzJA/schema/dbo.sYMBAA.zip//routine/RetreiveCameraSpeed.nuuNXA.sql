CREATE PROCEDURE [dbo].[RetreiveCameraSpeed]
AS
BEGIN
	update CameraEdge set Speed=dbo.sf_cameraspeed([JGCLZS]
      ,[JGCLPJSD]
      ,[CLZDJGSJ]
      ,[CLZXJGSJ])
      from [CAMERASERVER].[CameraDB].[dbo].[cameraspeed] a
      where a.gisid=CameraEdge.GISID
      
      update CameraInfo set LonLatCamera=a.JGCLPJSD,DataSource=a.JGCLZS,updatetime=a.JLSCSJ
      from [CAMERASERVER].[CameraDB].[dbo].[cameraspeed] a
      where a.gisid=CameraInfo.GISID
      
	update 	TrafficInfo set CameraSpeed=a.speed,UpdatedDt=GETDATE()
	from CameraEdge a 
	where a.EdgeId=TrafficInfo.EdgeId and a.Speed is not null and (TrafficInfo.CheckDt<GETDATE() or CheckDt is null)
END
GO

