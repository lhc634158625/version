CREATE PROCEDURE [dbo].[SynDSServiceData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN

	declare @maxDt datetime
	declare @minDt datetime
	declare @sql varchar(4000)
	select @minDt=MaxReceiveDt from SynDataLog
	--insert into ServiceType(Code,name,pcode,dstype)
	--	select bh,mc,sjbh,bh from openquery(DSDB,'select * from dsecs.V_DM_AY_VIEW') a
	--	where  not exists (select DSType from ServiceType where a.bh=dstype)
		
		set @sql='select t.*, (case when gljjdbh is null  then ''Y'' else ''N'' end) ismain,d.jc GXDWMC from DSECS.V_JJDB t,DSECS.V_BD_DW d where  t.GXDWBH=d.BH and substr(GXDWBH,5,3)<>''000'' and  SJBDSJ >sysdate-0.05 ';
		--set @sql='select * from DXCPZJB where ACCEPT_UNIT_NAME like ''%警务区'' and BDATE>=to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'') ';
		--and BDATE>=to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'') 
		set @sql='insert into RegionService(ReceiveDt,Type,RegionId,Memo,StationId,reportname,reporttel,reportaddress,Longitude,Latitude,typename,CASE_ID,Ora_LSH,MainEventFlag,ModifyTime,StartTime,AcceptUnitName,Code,FirstTime_UnitName,UpdateDt,AY)
		select a.HRSJ,c.Code,b.Id,a.BJNR,b.StationId,a.BJRXM,a.BJDH,a.AFDD,
		CASE WHEN XZB=null then  b.CenterX  when ISNUMERIC(xzb)<>1 then  b.CenterX  else XZB end, 
		CASE WHEN YZB=null then  b.CenterY when ISNUMERIC(yzb)<>1 then  b.CenterY else YZB end,

		c.Name,a.JQH, a.JQH,a.ismain,a.SJBDSJ,a.HRSJ,a.GXDWMC, a.jqh,GETDATE(),GETDATE(),a.AY from OpenQuery(DSDB, '''+replace(@sql,'''','''''')+''') a,
		SubRegion b, ServiceType c
		where SUBSTRING(a.GXDWMC,1,3)=b.Name 
		and a.AY=c.DSType		
		and  not exists (select 1 from RegionService where RegionService.Ora_LSH=a.JQH )';
		print @sql
		exec (@sql)
		set @sql='select t.*, (case when gljjdbh is null  then ''Y'' else ''N'' end) ismain,d.jc GXDWMC from DSECS.V_JJDB t,DSECS.V_BD_DW d where  t.GXDWBH=d.BH and substr(GXDWBH,5,3)<>''000'' and  SJBDSJ >sysdate-0.05 ';
		set @sql='update RegionService set StationId=a.stationId,type=a.type,typename=a.typename,UpdateDt=getdate(),Ay=a.ay
		from (
		select a.jqh, c.Code type,b.stationId stationId,c.Name typename,a.GXDWMC,a.AY from OpenQuery(DSDB, '''+replace(@sql,'''','''''')+''') a,
		SubRegion b, ServiceType c
		where SUBSTRING(a.GXDWMC,1,3)=b.Name 
		and a.AY=c.DSType
		) a where  RegionService.Ora_LSH=a.JQH ';
		print @sql
		exec (@sql)
		
		--无外协单位		
		set @sql='select t.*, (case when gljjdbh is null  then ''Y'' else ''N'' end) ismain,d.jc GXDWMC from DSECS.V_JJDB t,DSECS.V_BD_DW d where  t.GXDWBH=d.BH and t.gxdwbh not in(''350270999000'') and  SJBDSJ >sysdate-0.05 ';
		set @sql='insert into RegionService(ReceiveDt,Type,Memo,StationId,reportname,reporttel,reportaddress,Longitude,Latitude,typename,CASE_ID,Ora_LSH,MainEventFlag,ModifyTime,StartTime,AcceptUnitName,Code,FirstTime_UnitName,UpdateDt,Ay)
		select a.HRSJ,c.Code,a.BJNR,d.Id,a.BJRXM,a.BJDH,a.AFDD,
		CASE WHEN XZB=null then  d.CenterX  when ISNUMERIC(xzb)<>1 then  d.CenterX  else XZB end, 
		CASE WHEN YZB=null then  d.CenterY when ISNUMERIC(YZB)<>1 then  d.CenterY else YZB end,
		c.Name,a.JQH, a.JQH,a.ismain,a.SJBDSJ,a.HRSJ,a.GXDWMC, a.jqh,GETDATE(),GETDATE(),a.AY from OpenQuery(DSDB, '''+replace(@sql,'''','''''')+''') a,
		 ServiceType c, Station d
		where a.GXDWDM=d.SCode and d.isuse=1
		and a.AY=c.DSType
		and  not exists (select 1 from RegionService where RegionService.Ora_LSH=a.JQH )';
		print @sql
		exec (@sql)
		set @sql='select t.*, (case when gljjdbh is null  then ''Y'' else ''N'' end) ismain,d.jc GXDWMC from DSECS.V_JJDB t,DSECS.V_BD_DW d where  t.GXDWBH=d.BH and t.gxdwbh not in(''350270999000'') and  SJBDSJ >sysdate-0.05 ';
		set @sql='update RegionService set StationId=a.stationId,type=a.type,typename=a.typename,UpdateDt=getdate(),Ay=a.ay
		from (
		select a.jqh,c.Code type,d.Id stationId,c.Name typename,a.GXDWMC,a.AY from OpenQuery(DSDB, '''+replace(@sql,'''','''''')+''') a,
		 ServiceType c, Station d
		where a.GXDWDM=d.SCode and d.isuse=1
		and a.AY=c.DSType
		) a where  RegionService.Ora_LSH=a.JQH ';
		print @sql
		exec (@sql)
		--外协单位
		set @sql='select t.*, (case when gljjdbh is null  then ''Y'' else ''N'' end) ismain,''外协单位'' GXDWMC from DSECS.V_JJDB t where  SJBDSJ >sysdate-0.05 and SJBDSJ <sysdate-0.001 ';
		set @sql='insert into RegionService(ReceiveDt,Type,Memo,StationId,reportname,reporttel,reportaddress,Longitude,Latitude,typename,CASE_ID,Ora_LSH,MainEventFlag,ModifyTime,StartTime,AcceptUnitName,Code,FirstTime_UnitName,UpdateDt,Ay)
		select a.HRSJ,c.Code,a.BJNR,999999,a.BJRXM,a.BJDH,a.AFDD,
		CASE WHEN XZB=null then  null  when ISNUMERIC(xzb)<>1 then null  else XZB end, 
		CASE WHEN YZB=null then null when ISNUMERIC(YZB)<>1 then null else YZB end,
		c.Name,a.JQH, a.JQH,a.ismain,a.SJBDSJ,a.HRSJ,a.GXDWMC, a.jqh,GETDATE(),GETDATE(),a.AY from OpenQuery(DSDB, '''+replace(@sql,'''','''''')+''') a,
		 ServiceType c
		where  a.AY=c.DSType
		and  not exists (select 1 from RegionService where RegionService.Ora_LSH=a.JQH )';
		print @sql
		exec (@sql)
--	update CaseInfo set Longitude=RegionService.Longitude,Latitude=RegionService.Latitude
--from RegionService where RegionService.Ora_LSH=CaseInfo.CaseCODE and CaseInfo.OCCURTIME>DATEADD(day,-7,getdate()) and CaseInfo.Longitude is null
	
	--select @maxDt=MaxReceiveDt from SynDataLog	
	--同步到gps数据库
	--exec [SP_PushToGPS] @minDt,@maxDt	
	
END
GO

