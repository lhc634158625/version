
Create view [dbo].[vw_SWATPatrolTask20140715]
as
select t1.WorkDt,t1.DutyNumber,isnull(t2.ArrangeNumber,0) ArrangeNumber,DATEPART(dw,t1.WorkDt) DayOfWeek from 
	(select distinct WorkDt,SUM(DutyNumber) DutyNumber from SWATPatrolHis group by WorkDt) t1
left join 
	(select WorkDt,COUNT(*) ArrangeNumber from Scheduling group by WorkDt) t2
on t1.WorkDt=t2.WorkDt

GO

