CREATE PROCEDURE [dbo].[AutoCheckPeakOutSide]
	
AS
BEGIN
    --准时3分钟内1000米
	insert into PeakOutSide(StaffId,StaffName,Created,ArrangeId,StationId,Distance,Longitude,Latitude,TimeType,TimeName,[State])
	select a.StaffId,a.StaffName,GETDATE(), a.Id,a.StationId,dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.Longitude,6),ROUND(c.Latitude,6)),b.Longitude,b.Latitude,a.TimeType,a.TimeName,'准时'
	from ArrangeInfo a, Staff b, ShiftTime c
	where a.StaffId=b.Id and a.TimeType=c.Id and
	a.ShiftType=7 and a.FromTime<=GETDATE() and DATEADD(MI,3,a.FromTime)>=GETDATE() and DATEADD(MI,3,b.LastPosTime)>=GETDATE()
	and dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.Longitude,6),ROUND(c.Latitude,6))<=1000
	and not exists (select 1 from PeakOutSide where PeakOutSide.ArrangeId=a.Id and State='准时')

	--迟到3分钟后1000米
	insert into PeakOutSide(StaffId,StaffName,Created,ArrangeId,StationId,Distance,Longitude,Latitude,TimeType,TimeName,[State])
	select a.StaffId,a.StaffName,GETDATE(), a.Id,a.StationId,dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.Longitude,6),ROUND(c.Latitude,6)),b.Longitude,b.Latitude,a.TimeType,a.TimeName,'迟到'
	from ArrangeInfo a, Staff b, ShiftTime c
	where a.StaffId=b.Id and a.TimeType=c.Id and
	a.ShiftType=7 and DATEADD(MI,3,a.FromTime)<=GETDATE() and a.ToTime>=GETDATE() and DATEADD(MI,3,b.LastPosTime)>=GETDATE()
	and dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.Longitude,6),ROUND(c.Latitude,6))<=1000
	and not exists (select 1 from PeakOutSide where PeakOutSide.ArrangeId=a.Id and State in ('准时','迟到'))
	
	---早退1000米外
	insert into PeakOutSide(StaffId,StaffName,Created,ArrangeId,StationId,Distance,Longitude,Latitude,TimeType,TimeName,[State])
	select a.StaffId,a.StaffName,GETDATE(), a.Id,a.StationId,dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.Longitude,6),ROUND(c.Latitude,6)),b.Longitude,b.Latitude,a.TimeType,a.TimeName,'早退'
	from ArrangeInfo a, Staff b, ShiftTime c
	where a.StaffId=b.Id and a.TimeType=c.Id and
	a.ShiftType=7 and a.FromTime<=GETDATE() and DATEADD(MI,-3,a.ToTime)>=GETDATE() and DATEADD(MI,3,b.LastPosTime)>=GETDATE() 
	and dbo.fn_distance(ROUND(b.Longitude,6),ROUND(b.Latitude,6),ROUND(c.Longitude,6),ROUND(c.Latitude,6))>1000
	and exists (select 1 from PeakOutSide where PeakOutSide.ArrangeId=a.Id and State in ('准时','迟到'))
	and not exists (select 1 from PeakOutSide where PeakOutSide.ArrangeId=a.Id and State='早退')

	---巡逻必到点
	insert into PeakOutSide(StaffId,StaffName,Created,ArrangeId,StationId,Distance,Longitude,Latitude,TimeType,TimeName,[State])
	select a.Id,a.Name,GETDATE(), b.Id,a.StationId,dbo.P2LDistance(ROUND(a.Longitude,6),ROUND(a.Latitude,6),ROUND(a.PrevX,6),ROUND(a.PrevY,6),ROUND(b.FromX,6),ROUND(b.FromY,6)),a.Longitude,a.Latitude,b.EdgeId,b.RoadName,'巡逻'
	from DeviceInfo a, RoutePlanDetail b
	where a.RegionId=b.EdgeId 
		and a.[Type]='巡逻车台'
		and b.[State]<>'确定'
		and DATEADD(MI,30,a.LastPosTime)>=GETDATE()
		and dbo.P2LDistance(ROUND(a.Longitude,6),ROUND(a.Latitude,6),ROUND(a.PrevX,6),ROUND(a.PrevY,6),ROUND(b.FromX,6),ROUND(b.FromY,6))<400
		and not exists (select 1 from PeakOutSide where PeakOutSide.StaffId=a.Id and PeakOutSide.[State]='巡逻' and DATEADD(MI,30,PeakOutSide.Created)>GETDATE())
END
GO

