Create procedure [dbo].[sp_AddRouteRoad](@RouteId int,@roadId int,@Creater int)
  as
  begin
  delete routeplandetail where routeId=@routeid and roadid=@roadId
  insert into routeplandetail( routeid,roadid,roadname,RoadType,RoadDirect,edgeid,fromx,fromy,tox,toy,state,creater,created)
  select @routeId,@roadId,roadName,a.roadType,Direct,b.KANTEN_ID,FromX,FromY,ToX,ToY,'确定',@creater,GETDATE()
  from MAP_ROADINFO a ,MAP_EDGEDATA b
   where a.ROADID=@roadId and a.ROADID=b.ROADID and b.DIRECT=1
  
  end
GO

