/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_i_VehicleState] 
   ON  [dbo].[VehicleState]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO13' ,'dbo'  ,'VehicleState' ,'Handphone=' + convert(varchar(50),inserted.Handphone) ,'I',0, 'IDB47TO13dboVehicleStateHandphone=' + convert(varchar(50),inserted.Handphone) 
    from inserted
END
GO

