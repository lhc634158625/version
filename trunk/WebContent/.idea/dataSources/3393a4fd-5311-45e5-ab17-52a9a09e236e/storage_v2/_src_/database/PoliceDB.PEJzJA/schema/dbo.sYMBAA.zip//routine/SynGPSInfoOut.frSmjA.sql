CREATE PROCEDURE [dbo].[SynGPSInfoOut]
AS
BEGIN 
	DECLARE @maxId int
	DECLARE @minId int
	SELECT @minId=[OGPSInfoId] from [DataMigrationParam]
	SELECT @maxId=MAX([Id]) FROM [GPSInfo]
	IF @maxId>(@minId+1000) 
	BEGIN
	SET @maxId = @minId+1000
	END
	ELSE
	BEGIN
	RETURN
	END
	
	--BEGIN TRAN mytran
	---插入目标
	INSERT INTO [100.168.60.35].[TempPolice].[dbo].[GPSInfo](
		  [Id]
      ,[DevCode]
      ,[Longitude]
      ,[Latitude]
      ,[ReceiveDt]
      ,[PosDesc]
      ,[Peoples]
      ,[ServiceId]
      ,[DevName]
      ,[StorageTime]
      ,[CreateTime]
      ,[Attribute]
      ,[AlarmType]
      ,[Flag]
      ,[Speed]
      ,[Direction]
      ,[Mileage])
	SELECT [Id]
      ,[DevCode]
      ,[Longitude]
      ,[Latitude]
      ,[ReceiveDt]
      ,[PosDesc]
      ,[Peoples]
      ,[ServiceId]
      ,[DevName]
      ,[StorageTime]
      ,[CreateTime]
      ,[Attribute]
      ,[AlarmType]
      ,[Flag]
      ,[Speed]
      ,[Direction]
      ,[Mileage]
	  FROM [GPSInfo]
	  WHERE [Id] > @minId AND [Id] < @maxId

	---更新参数表
	UPDATE [DataMigrationParam] SET [OGPSInfoId]=@maxId
	/*	
	IF @@ERROR<>0 
	BEGIN
		ROLLBACK TRAN mytran
	END
	ELSE
	BEGIN
		COMMIT TRAN mytran
	END	  
	---结束事物
	*/
END

GO

