
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetCommunicateReport](@begindt datetime,@enddt datetime,@stationId int, @type varchar(50), @callType varchar(50))
AS
BEGIN
declare @pid int
declare @rc int
select @pid=pid from Station where Id=@stationId
select @rc=COUNT(id) from Station where PId=@stationId
	if(@type='下属机构')
	begin	
	if(@pid=0 or @pid=1) --市局 
		select COUNT(id) as RecordCount,state as State,cast(PStation as varchar(10)) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
		group by State,PStation
	else
		begin
			
			if @rc>0 --区局
				select COUNT(id) as RecordCount,state as State,cast(Station as varchar(10)) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and pstation=@stationId and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
				group by State,Station
			else --派出所
			select COUNT(id) as RecordCount,state as State,cast(regionId as varchar(10)) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and station=@stationId and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
				group by State,RegionId
		end
	end
	if(@type='日报表')
	begin
		if(@pid=0 or @pid=1) --市局 
		select COUNT(id) as RecordCount,state as State,convert(varchar(10),Created,120) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
		group by State,convert(varchar(10),Created,120)
	else
		begin
			
			if @rc>0 --区局
				select COUNT(id) as RecordCount,state as State,convert(varchar(10),Created,120) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and pstation=@stationId and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
				group by State,convert(varchar(10),Created,120)
			else --派出所
			select COUNT(id) as RecordCount,state as State,convert(varchar(10),Created,120) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and station=@stationId and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
				group by State,convert(varchar(10),Created,120)
		end
		
	end 
	if(@type='时段报表')
	begin
		if(@pid=0 or @pid=1) --市局 
		select COUNT(id) as RecordCount,state as State,CAST([Hour] as varchar(10)) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
		group by State,Hour
	else
		begin			
			if @rc>0 --区局
				select COUNT(id) as RecordCount,state as State,CAST([Hour] as varchar(10)) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and pstation=@stationId and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
				group by State,Hour
			else --派出所
			select COUNT(id) as RecordCount,state as State,CAST([Hour] as varchar(10)) as OwnerId,0 RegionId  from CommunicateLog where Created between @begindt and @enddt and station=@stationId and CallType like '%' +@callType + '%' and rtrim(SrcCallType)='人工语音'
				group by State,Hour
		end
		
	end 
END
GO

