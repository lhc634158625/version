CREATE FUNCTION [dbo].[GetChildIds]
(
	@id int,	
	@item varchar(50)
)
RETURNS @r TABLE(Id int)
AS
Begin
declare @code varchar(10)
select @code=code from station where id=@id

    IF (@item='station_isuse')
		with cte as  
		 (  
			 select Id,PId,IsUse from Station where Id=@id and isuse=1
			 union all   
			 select s.Id,s.PId,s.IsUse from Station s inner join cte c on s.pid = c.id  where s.isuse=1
			-- select id from station where code like @code+'%' and isuse=1
		 )
        INSERT @r SELECT Id FROM cte 
   
    IF (@item='station')
		with cte as  
		 (  
			 select Id,PId,IsUse from Station where Id=@id
			 union all   
			 select s.Id,s.PId,s.IsUse from Station s inner join cte c on s.pid = c.id 
			--select id from station where code like @code+'%'  
		 )
        INSERT @r SELECT Id FROM cte
 RETURN  
   
end
GO

