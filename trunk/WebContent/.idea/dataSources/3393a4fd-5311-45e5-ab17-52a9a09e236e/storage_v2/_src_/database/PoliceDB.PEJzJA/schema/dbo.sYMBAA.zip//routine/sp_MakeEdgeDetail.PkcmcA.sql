Create    PROCEDURE [dbo].[sp_MakeEdgeDetail](@region VARCHAR(6),@zoom int)
 AS
/*******************************************************************************
** 描述:  获得道路交叉关系数据表RoadRelation
**
** Copyright (c) InfoGIS Co.Ltd. All Rights Reserved. 
** 
******************************************************************************* */
SET NOCOUNT ON
declare @masterID         int
       
       ,@fromx      float
       ,@fromy       float
     ,@tox      float
       ,@toy       float
       ,@val float
     ,@angle int
      
delete from EdgeDetail where MasterId in(select Id from EdgeMaster where Region=@region  and Zoom=@zoom)
declare edge_cursor CURSOR for
select [ID],fromx,fromy,tox,toy,angle from EdgeMaster 
where region=@region and zoom=@zoom and
not exists (select masterid from EdgeDetail where edgedetail.masterid=edgemaster.id) 
order by id
--select [ID],fromx,fromy,direct from EdgeData 
--where region=@region and direct>0
--order by id
open edge_cursor

fetch next from edge_cursor
into @masterID,@fromx,@fromy,@tox,@toy,@angle

while @@FETCH_STATUS = 0
begin

 if(@fromx>@tox)
 begin
	set @val=@tox
	set @tox=@fromx
	set @fromx=@val
 end
 if(@fromy>@toy)
 begin
	set @val=@toy
	set @toy=@fromy
	set @fromy=@val
 end	
 insert into EdgeDetail(MasterId,EdgeId)
 select @masterid,EdgeId
 from TrafficInfo where  angle>@angle-10 and angle<@angle+10
 and fromx>=@fromx-0.01 and fromx<=@tox+0.01
 and fromy>=@fromy-0.01 and fromy<@toy+0.01

  fetch next from edge_cursor
  into @masterID,@fromx,@fromy,@tox,@toy,@angle
end

close edge_cursor
deallocate edge_cursor

GO

