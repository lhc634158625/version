Create  function [dbo].[fn_distance](@fromx float,@fromy float,@tox float,@toy float)
returns float
as
begin
return sqrt((@tox-@fromx)*(@tox-@fromx)*101296*101296+(@toy-@fromy)*(@toy-@fromy)*111319*111319)
end
GO

