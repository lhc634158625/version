

Create   FUNCTION [dbo].[Angle](@x1 float,@y1 float,@x2 float ,@y2 float)
RETURNS float AS  
BEGIN 
declare @dx float, @dy float, @angle float, @ret float;
            set @dy = @y2 - @y1;
            set @dx = @x2 - @x1;
            set @angle = Atn2(Abs(@dy), Abs(@dx));
            set @angle = 360.0 * @angle / (2 * PI());
            if (@dx >= 0) and (@dy >= 0)
               return @angle;
           if (@dx <= 0) and (@dy >= 0)
               return 180.0 - @angle;
             if (@dx <= 0) and (@dy <= 0)
                return 180.0 + @angle;
            
               return 360.0 - @angle;
          
--return cast(@retdis as int)
END
GO

