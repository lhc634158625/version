CREATE PROCEDURE [dbo].[SynExpiredGPSData] 
	(@date1 datetime)
AS
BEGIN
	--GPS
	Insert Into PoliceDB_his..[GPSInfo]  select * from PoliceDB..[GPSInfo] where ReceiveDt<dateadd(day,-15,@date1)
	Delete  from PoliceDB..[GPSInfo] where ReceiveDt<dateadd(day,-15,@date1)
	
END
GO

