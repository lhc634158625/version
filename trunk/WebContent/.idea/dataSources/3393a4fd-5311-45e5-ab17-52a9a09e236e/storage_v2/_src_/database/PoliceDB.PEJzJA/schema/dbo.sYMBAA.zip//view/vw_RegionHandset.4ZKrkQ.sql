

     CREATE view [dbo].[vw_RegionHandset](Name,DevCode,Station,Region,StationId,RegionId)
     as 
     select distinct a.Name,a.HandsetCode,b.Name,c.Name,b.id,c.id
     from Staff a,Station b,SubRegion c, ArrangeInfo d
     where a.Station=b.Id and a.RegionId=c.Id
		and LEN(a.HandsetCode)=10
		and d.StaffId=a.Id and d.FromTime<=GETDATE() and d.ToTime>=GETDATE()
	 union
     select distinct a.Name,a.HandsetCode,b.Name,'',b.id,0
     from Staff a,Station b, ArrangeInfo d
     where a.Station=b.Id and d.ShiftType=1
		and LEN(a.HandsetCode)=10
		and d.StaffId=a.Id and ((d.FromTime<=GETDATE() and d.ToTime>=GETDATE()) or a.Id in (723,776))

     GO

