CREATE PROCEDURE [dbo].[SynParkData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	declare @maxId bigint
	declare @minId bigint
	select @minId=ParkOverTimeId from syndatalog
	select @maxId=MAX([ParkingOvertimeID]) from  [GPSCENTER].[TXServer].[dbo].[ParkingOvertime]

	insert into [ParkingOverTime]([ID]
      ,[VehicleID]
      ,[BeginTime]
      ,[EndTime]
      ,[ParkTime]
      ,[Overtime]
      ,[StationId]
      ,[RegionId])
      select [ParkingOvertimeID]
      ,[VehicleID]
      ,[BeginParkingTime]
      ,[EndParkingTime]
      ,[ParkingSecond]
      ,[ParkingOvertime]
      ,StationId
      ,RegionId
      from [GPSCENTER].[TXServer].[dbo].[ParkingOvertime] a,DeviceInfo
      where a.[VehicleID]=DeviceInfo.Code and a.[ParkingOvertimeID]>@minId and a.[ParkingOvertimeID]<@maxId and DeviceInfo.Type='巡逻车台'
	

	
	update syndatalog set ParkOverTimeId=@maxId
	
END
GO

