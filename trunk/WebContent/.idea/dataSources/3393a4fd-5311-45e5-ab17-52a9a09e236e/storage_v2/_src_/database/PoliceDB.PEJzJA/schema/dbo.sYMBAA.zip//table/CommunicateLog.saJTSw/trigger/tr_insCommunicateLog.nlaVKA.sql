-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER tr_insCommunicateLog 
   ON dbo.CommunicateLog
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	update subregion set CommState=inserted.State
	from inserted where inserted.regionid=subregion.id
    -- Insert statements for trigger here

END
GO

