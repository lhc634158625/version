
CREATE TRIGGER [dbo].[tr_updateTrafficInfo]
ON  [dbo].[TrafficInfo]
   AFTER  UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--SET NOCOUNT ON;

    -- Insert statements for trigger here
	update trafficinfo set changedt=GETDATE(),oldspeed=dbo.fn_speed(deleted.speed,deleted.cameraspeed,deleted.busspeed) 
	from deleted 
	where deleted.EdgeId=trafficinfo.EdgeId and dbo.fn_speed(trafficinfo.speed,trafficinfo.cameraspeed,trafficinfo.busspeed)<>deleted.oldspeed
	
	update edgedetail set speed=inserted.speed,busspeed=inserted.busspeed,cameraspeed=inserted.cameraspeed
	from inserted 
	where inserted.EdgeId=edgedetail.EdgeId
	
END
GO

