create TRIGGER [dbo].[tr_insNewDeviceInfo]
   ON [dbo].[NewDeviceInfo]
   AFTER insert
AS 
BEGIN
	insert into DeviceInfo(Name,Type,StationId,Param,Code,Manufacturer,remark,assembletype,assemblecode,scode)

select a.name,DeviceType.Name,Station.Id,sim, dbo.getoldcode(a.code),videoId,a.assemblingcode,assemblingtype,assemblingcode,a.code from inserted a,Station,DeviceType where 
Station.SCode=a.userCode and devicetype.Param=a.type and station.isuse=1 and station.id in(select stationid from stationgroup where groupid=5)
and
not exists(select id from DeviceInfo where DeviceInfo.code=a.code)
SET NOCOUNT ON;
END
GO

