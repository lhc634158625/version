--SELECT *  FROM [ORASERVER]..[XM110].[CASE_FLOW7D]
  
  
  create view aa
	as
	select s.casetypeids,t.* from [ORASERVER]..[XM110].[CASE_FLOW7D] t 
		left join casetype s on check_case_type=casetype
		where substring(case_id,12,8)>'20120515' and substring(case_id,12,8)<'20120521'
GO

