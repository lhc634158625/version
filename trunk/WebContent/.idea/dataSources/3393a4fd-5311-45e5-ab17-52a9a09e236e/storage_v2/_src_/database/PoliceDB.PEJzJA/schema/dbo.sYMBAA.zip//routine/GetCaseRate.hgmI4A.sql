CREATE FUNCTION  [dbo].[GetCaseRate]
(
	-- Add the parameters for the function here
	@avg int,
	@comm int,
	@thiscount int,
	@isBranch int
)
RETURNS int
AS
BEGIN
declare @rate float
if @thiscount is null return 4
 if(@avg<=5)
 begin
	if((@thiscount-@comm)>6) return 1
	if((@thiscount-@comm)>4) and  ((@thiscount-@comm)<=6) return 2
	if((@thiscount-@comm)>2) and  ((@thiscount-@comm)<=4) return 3
	if((@thiscount-@comm)<=2) return 4
 end
 if(@comm=0)return 0
 set @rate=100.0*(@thiscount-@comm)/@comm
 if(@avg>5) and (@avg<=15)
 begin
	if(@rate>=35) return 1
	if(@rate<35) and (@rate>=25) return 2
	if(@rate<25) and (@rate>=15) return 3
	if(@rate<15) return 4
 end
 if(@isBranch=1)
 begin
  if(@rate>=25) return 1
	if(@rate<25) and (@rate>=15) return 2
	if(@rate<15) and (@rate>=5) return 3
	if(@rate<5) return 4
 end
 if(@rate>=25) return 1
	if(@rate<25) and (@rate>=15) return 2
	if(@rate<15) and (@rate>=8) return 3
	if(@rate<8) return 4
	
 return 4
 
END
GO

