
CREATE procedure [dbo].[sp_CameraEdge]
  as
  begin
  declare  cur_camera cursor for select lon,lat,gisid,knoten_id from  policedb..camerainfo a, map_nodedata b where devicetype='01' and Lon is not null
  and dbo.fn_distance(lon,Lat,geo_x,geo_y)<100
  declare @lon float,@lat float,@gisid varchar(50)
  declare @nodeId int,@edgeid int
  open cur_camera
  fetch  NEXT FROM cur_camera into @lon,@lat,@gisid,@nodeId;
  while @@FETCH_STATUS=0
  begin
  insert into cameraedge(gisid,edgeid,FromX,FromY,ToX,ToY)
  select @gisid,kanten_id,a.GEO_X,a.GEO_Y,b.GEO_X,b.GEO_Y from map_edgedata,MAP_NODEDATA a,MAP_NODEDATA b where (knoten_id_from=@nodeId or knoten_id_to=@nodeId)
  and kanten_id not in(select edgeid from CameraEdge where gisid=@gisid)
  and KNOTEN_ID_FROM=a.KNOTEN_ID and KNOTEN_ID_TO=b.KNOTEN_ID
  
  fetch NEXT FROM cur_camera into @lon,@lat,@gisid,@nodeId
  end
  close cur_camera
  deallocate cur_camera
  end
GO

