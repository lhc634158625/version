-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER  [dbo].[TR_INDEXKEY]
   ON  [dbo].[DMSyncData]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @sType varchar(50)
	DECLARE @sTableName varchar(50)
	select @sType=[Type], @sTableName=[TableName] from inserted
    -- Insert statements for trigger here
    
    if @sType = 'U' 
	begin
		if(exists(select top 1 1 from DMSyncData WITH(READPAST), inserted a
		where DMSyncData.[status]=0 and DMSyncData.[IndexKey]=a.[IndexKey] and DMSyncData.ID != a.ID 
		))
		begin
			update DMSyncData set [Status]=1
			from inserted
			where DMSyncData.ID = inserted.ID 
		end	
	END	
END
GO

