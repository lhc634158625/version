
CREATE FUNCTION [dbo].[P2LDistance](@begin_x float,@begin_y float,@end_x float,@end_y float, @x float,@y float)
RETURNS float AS  
BEGIN 
declare @distance1 float
declare @distance2 float
declare @distance3 float
declare @distance float
declare @delta1 float
declare @delta2 float
set @distance1=dbo.fn_distance(@begin_x,@begin_y,@x,@y)
set @distance2=dbo.fn_distance(@end_x,@end_y,@x,@y)
declare @linedistance float
set @linedistance=dbo.fn_distance(@begin_x,@begin_y,@end_x,@end_y)
set @end_x=(@end_x -@begin_x)*87622.33
set @end_y=(@end_y-@begin_y)*111194.874284
set @x=(@x-@begin_x)*87622.33
set @y=(@y-@begin_y)*111194.874284
set @distance=sqrt(@end_y*@end_y+@end_x*@end_x) 
if @distance=0 
	set @distance=0
else
set @distance=abs(@end_y*@x - @end_x*@y)/@distance



--return @linedistance

if @distance1>@distance2 
begin
	if (@distance1*@distance1-@distance*@distance)>@linedistance*@linedistance 
		return @distance2
	else
		return @distance		
end
else
if @distance1=@distance2 
return @distance1
else
begin
	if (@distance2*@distance2 -@distance*@distance)>@linedistance*@linedistance 
		return @distance1
	else
		return @distance	
end
return 0
/*if @distance1<@distance
	return @distance1
if @distance2<@distance
	return @distance2
return @distance
*/
END

GO

