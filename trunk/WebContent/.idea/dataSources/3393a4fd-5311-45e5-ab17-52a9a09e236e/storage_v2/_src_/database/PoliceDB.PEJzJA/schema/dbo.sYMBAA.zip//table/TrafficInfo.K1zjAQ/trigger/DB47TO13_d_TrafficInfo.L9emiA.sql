/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_d_TrafficInfo] 
   ON  [dbo].[TrafficInfo]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO13' ,'dbo'  ,'TrafficInfo' ,'EdgeId=' + convert(varchar(50),deleted.EdgeId),'D',0,'DDB47TO13dboTrafficInfoEdgeId=' + convert(varchar(50),deleted.EdgeId) 
    from deleted
END
GO

