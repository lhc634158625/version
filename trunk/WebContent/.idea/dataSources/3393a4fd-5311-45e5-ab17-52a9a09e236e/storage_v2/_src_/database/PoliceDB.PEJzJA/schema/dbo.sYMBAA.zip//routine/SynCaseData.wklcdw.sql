
CREATE PROCEDURE [dbo].[SynCaseData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	declare @maxDt datetime
	declare @minDt datetime
	select @minDt=CaseInfoDt from syndatalog
	set @maxDt=GETDATE()	
	set @minDt=DATEADD(DAY,-1,@minDt)
	
	declare @sql varchar(4000)
	set @sql='select a.jqh CaseCode,a.bjymc Reporter,a.bjyhm ReportTel,a.bjrlxfs ContactTel,b.lsh Code,b.afdz OccurAddress,
b.bjsj OccurTime,AJLX||''-''||AJXZ||decode(xzfl,null,'''',''-''||XZFL) CaseType,b.bz Description,sxpcs Station,fabw,b.gxsj,b.zasd
 from JJXX_YW_JBJBXX a,hfb b
 where 
a.bjid||a.ajid=b.lsh and  b.gxsj>to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'') and
(AJXZ=''诈骗'' or (fabw=''居民住宅'' and  xzfl=''入室盗窃'') or (fabw=''内部单位'' and ajxz=''盗窃'')) and b.bjsj>=to_date(''2012-08-01'',''yyyy-mm-dd HH24:MI:SS'')'


	set @sql='insert into CaseInfo([CASECODE],[REPORTER],[REPORTTEL],[CONTACTTEL],[CODE],[OCCURADDRESS],[OCCURTIME],[CASETYPE],[DESCRIPTION],[STATION],[FABW],[GXSJ],[CrimeMeans],StationCode) 
		select a.*,b.Code
		from OpenQuery(CASESERVER, '''+replace(@sql,'''','''''')+''') a, Station b
		where a.station=b.oldname and NOT EXISTS (SELECT ID from caseinfo where caseinfo.casecode=a.casecode)'
	--print @sql
	exec (@sql)


	set @sql='select a.jqh CaseCode,a.bjymc Reporter,a.bjyhm ReportTel,a.bjrlxfs ContactTel,b.lsh Code,b.afdz OccurAddress,
b.bjsj OccurTime,AJLX||''-''||AJXZ||decode(xzfl,null,'''',''-''||XZFL) CaseType,b.bz Description,sxpcs Station,fabw,b.gxsj,b.zasd
 from JJXX_YW_JBJBXX a,hfb b
 where a.bjid||a.ajid=b.lsh and  b.gxsj>to_date('''+convert(varchar(20),@minDt,120)+''',''yyyy-mm-dd HH24:MI:SS'') and b.bjsj>=to_date(''2012-08-01'',''yyyy-mm-dd HH24:MI:SS'')'

-- and (AJXZ=''诈骗'' or (fabw=''居民住宅'' and  xzfl=''入室盗窃'') or (fabw=''内部单位'' and ajxz=''盗窃'')) 

	set @sql='update caseinfo set casetype=a.casetype,updatetime=getdate(),fabw=a.fabw, StationCode=b.Code, Station=a.Station
		from OpenQuery(CASESERVER, '''+replace(@sql,'''','''''')+''') a, Station b
		where a.station=b.oldname and a.casecode=caseinfo.casecode'
	--print @sql
	exec (@sql)

	
	update syndatalog set CaseInfoDt=@maxDt
	
END
GO

