/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_u_DeviceInfo] 
   ON  [dbo].[DeviceInfo]
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;	
    declare @Remark nvarchar(MAX)
    set @Remark= ''
    

                                            if update(Name) BEGIN SET @Remark = @Remark +'Name,' END
                                            if update(Type) BEGIN SET @Remark = @Remark +'Type,' END
                                            if update(VideoType) BEGIN SET @Remark = @Remark +'VideoType,' END
                                            if update(StationId) BEGIN SET @Remark = @Remark +'StationId,' END
                                            if update(Param) BEGIN SET @Remark = @Remark +'Param,' END
                                            if update(Code) BEGIN SET @Remark = @Remark +'Code,' END
                                            if update(State) BEGIN SET @Remark = @Remark +'State,' END
                                            if update(RegionId) BEGIN SET @Remark = @Remark +'RegionId,' END
                                            if update(ShiftType) BEGIN SET @Remark = @Remark +'ShiftType,' END
                                            if update(staff_code) BEGIN SET @Remark = @Remark +'staff_code,' END
                                            if update(Remark) BEGIN SET @Remark = @Remark +'Remark,' END
                                            if update(IsUse) BEGIN SET @Remark = @Remark +'IsUse,' END
                                            if update(UserName) BEGIN SET @Remark = @Remark +'UserName,' END
                                            if update(UserId) BEGIN SET @Remark = @Remark +'UserId,' END
                                            if update(BindType) BEGIN SET @Remark = @Remark +'BindType,' END
                                            if update(DeviceState) BEGIN SET @Remark = @Remark +'DeviceState,' END
                                            if update(DeviceLogId) BEGIN SET @Remark = @Remark +'DeviceLogId,' END    

    if @Remark !=''
    BEGIN
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey],[Fields])
    select 'DB47TO13' ,'dbo'  ,'DeviceInfo' ,'Id=' + convert(varchar(50),inserted.Id),'U',0, 'UDB47TO13dboDeviceInfoId=' + convert(varchar(50),inserted.Id),@Remark
    from inserted
    End
END
GO

