CREATE PROCEDURE [dbo].[Sp_SendSMS]
	-- Add the parameters for the stored procedure here
	@content varchar(250),
	@To varchar(250),
	@creater int
AS
BEGIN
	INSERT INTO [SMSERVIVER].[sms].[dbo].[sm_tosend]
           ([thetime]
          
           ,[mobile]
           ,[message]
           ,[issend]
           ,[creater]
           ,[ip]
           ,[spnum]
           ,[unit])
     VALUES
         ( getdate()          
           ,@To
           ,@content
           ,0
           ,'duty110'
           ,'100.168.60.32'
           ,'0592999'
           ,'厦门公安指挥中心')
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	return 
END
GO

