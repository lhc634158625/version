CREATE FUNCTION [dbo].[MonthDay] 
(
	-- Add the parameters for the function here
	@month varchar(6)
)
RETURNS  int
AS
BEGIN
	declare @firstdate date,@lastdate date
	set @firstdate=cast(substring(@month,1,4)+'-'+substring(@month,5,2)+'-01' as datetime)
	set @lastdate=dateadd(month,1,@firstdate)
	return datediff(day,@firstdate,@lastdate)

END
GO

