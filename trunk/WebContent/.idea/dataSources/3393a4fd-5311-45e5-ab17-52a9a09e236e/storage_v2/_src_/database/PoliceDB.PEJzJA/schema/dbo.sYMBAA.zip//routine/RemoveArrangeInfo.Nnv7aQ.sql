Create PROCEDURE RemoveArrangeInfo
	(@stationId int, @workDt datetime)
AS
BEGIN
	delete from ArrangeInfo 
	where StationId=@stationid and DATEDIFF(day,WorkDt,@workDt)<=0
END
GO

