-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_UpdateDevCodeOnduty]

AS
BEGIN
	insert into  [GPSCENTER].[TXServer].[dbo].[Staff] (
	   [Id]
      ,[Station]
      ,[Region]
      ,[Name]
      ,[Telephone]
      ,[Position]
      ,[Onduty]
      ,[VerhicleId]
      ,[SaveTime]
      )
SELECT [Id]
	  ,[StationId]
	  ,[RegionId]
      ,[Name]
      ,null
      ,null
      ,0
      ,[Code]
      ,GETDATE()  
  FROM [PoliceDB].[dbo].[DeviceInfo] d
  where d.Type='巡逻车台' --and d.StationId>0 and d.RegionId >0
  and d.Id not in(select Id from [GPSCENTER].[TXServer].[dbo].[Staff])
  
  update [GPSCENTER].[TXServer].[dbo].[Staff] set [Onduty]= (case when d.Id is null then 0 else 1 end),[SaveTime]=GETDATE()
  From [GPSCENTER].[TXServer].[dbo].[Staff] s
  left join (select * from [PoliceDB].[dbo].[DeviceInfo]
			 where Type='巡逻车台' --and StationId>0 and RegionId >0
			 and RegionId in(SELECT distinct [RegionId] FROM [PoliceDB].[dbo].[ArrangeInfo] where  ShiftType=4 and  FromTime<GETDATE() and ToTime >GETDATE())) d
  on d.Id =s.Id
  
END
GO

