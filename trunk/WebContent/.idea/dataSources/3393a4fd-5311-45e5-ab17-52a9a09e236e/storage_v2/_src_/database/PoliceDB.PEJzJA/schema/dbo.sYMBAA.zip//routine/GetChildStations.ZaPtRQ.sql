CREATE FUNCTION [dbo].[GetChildStations]
(
	@ids varchar(500),	
	@item varchar(50)
)
RETURNS @r TABLE(Id int)
AS
Begin


    IF (@item='station_isuse')
		with cte as  
		 (  
			 select Id,PId,IsUse from Station where Id in(select * from dbo.[f_splitSTR](@ids,',')) and isuse=1
			 union all   
			 select s.Id,s.PId,s.IsUse from Station s inner join cte c on s.pid = c.id  
			 
		 )
        INSERT @r SELECT Id FROM cte 
   
    IF (@item='station')
		with cte as  
		 (  
			 select Id,PId,IsUse from Station where Id in(@ids)
			 union all   
			 select s.Id,s.PId,s.IsUse from Station s inner join cte c on s.pid = c.id 
			
		 )
        INSERT @r SELECT Id FROM cte
 RETURN  
   
end
GO

