-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[tr_insArrangeInfo] 
   ON  dbo.ArrangeInfo
   AFTER INSERT,UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
insert into [DutyDB].[dbo].[DutyInfo](workdt
      ,[Station]
       ,[StationCode]
      ,[Code]
      ,[Name]
      ,[FromDt]
      ,[ToDt]
      ,[ShiftType]
      ,[UpdateDt]
      )
  
  select workdt,b.name,b.code,c.code,c.name,a.fromtime,a.totime,d.pname,GETDATE()
  from inserted a ,station b,Staff c,shifttype d
  where a.StationId=b.Id and a.StaffId=c.Id and a.ShiftType=d.id
    -- Insert statements for trigger here

END
GO

DISABLE TRIGGER tr_insArrangeInfo ON ArrangeInfo
GO

