-- =============================================
CREATE PROCEDURE [dbo].[SynResultData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	
	update RegionService set result=a.myd1
	from [SMSERVIVER].[sms].[dbo].[短信测评中间表] a
	where a.[bdate]>GETDATE()-17
	and a.flag is not null
	and a.case_id=RegionService.case_id
	
END
GO

