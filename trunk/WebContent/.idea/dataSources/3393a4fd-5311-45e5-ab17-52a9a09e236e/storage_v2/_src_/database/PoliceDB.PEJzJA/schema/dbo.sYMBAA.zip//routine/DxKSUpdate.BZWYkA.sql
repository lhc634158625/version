CREATE PROCEDURE [dbo].[DxKSUpdate]
	
AS
BEGIN
insert into [SMSERVIVER].[sms].[dbo].[锁匠短信反馈](lsh,sendtime,sjname,msg)
select [dispatch_id],dispatch_time ,accept_unit_name sjname,dispatch_content msg--,dispatch_type
        FROM [ORASERVER]..[XM110].[DISPATCH_LOG7D]
                where  accept_unit_Name like '%锁匠%'  
						and dispatch_time>(SELECT MAX(SENDTIME) FROM [SMSERVIVER].[sms].[dbo].[锁匠短信反馈]) 
							and DISPATCH_ID NOT IN (SELECT LSH FROM [SMSERVIVER].[sms].[dbo].[锁匠短信反馈]) 
							order by dispatch_time
	
END
GO

