CREATE PROCEDURE [dbo].[GetServiceReport](@begindt varchar(20),@enddt varchar(20),@stationIds varchar(500),@caseType varchar(500),@shiftType varchar(500), @type varchar(50))
AS
BEGIN
declare @sql varchar(4000)
if(@type='日期')
begin
set @sql='select a.ItemName,isnull(sum(a.ServiceRc),0) ServiceRc,isnull(sum(a.PoliceRC),0) PoliceRC from
( select convert(varchar(10),receivedt,120) ItemName,1 ServiceRc,0 PoliceRC from RegionService where receivedt>='''+@begindt+''' and receivedt<='''+@enddt+'''  and stationid in(select Id from dbo.[GetChildStations]('''+@stationIds+''',''station_isuse'')) and  Type in (select CaseTypeIDS from CaseType where ProvinceCaseTypeIDS like ''' + @caseType + '%'') union all
select convert(varchar(10),workdt,120) ItemName,0 ServiceRc,1 PoliceRC from ArrangeInfo where workdt>='''+@begindt+''' and workdt<='''+@enddt+'''  and stationid in(select Id from dbo.[GetChildStations]('''+@stationIds+''',''station_isuse'')) and  ShiftType in (' + @shiftType + ')) a group by a.itemname  order by itemname'
end
if(@type='时段')
begin
set @sql='select a.ItemName,sum(a.ServiceRC) ServiceRC,isnull(sum(a.PoliceRC),0) PoliceRC from
( select substring(convert(varchar(13),receivedt,120),12,2) ItemName,1 ServiceRc,0 PoliceRC from RegionService where receivedt>='''+@begindt+''' and receivedt<='''+@enddt+'''  and stationid in(select Id from dbo.[GetChildStations]('''+@stationIds+''',''station_isuse'')) and  Type in (select CaseTypeIDS from CaseType where ProvinceCaseTypeIDS like ''' + @caseType + '%'') union all
select basedict.code ItemName,0 ServiceRc,dbo.InWorking(workdt, basedict.code,fromtime,totime) PoliceRC from ArrangeInfo,basedict where basedict.dictname=''ShiftHour'' and workdt>='''+@begindt+''' and workdt<'''+@enddt+''' and  stationid in(select Id from dbo.[GetChildStations]('''+@stationIds+''',''station_isuse'')) and  ShiftType in (' + @shiftType + '))a group by a.itemname order by itemname'
end
if(@type='分局')
begin
set @sql='select a.ItemName,sum(a.ServiceRC) ServiceRC,isnull(sum(a.PoliceRC),0) PoliceRC from
( select b.name ItemName,1 ServiceRc,0 PoliceRC from RegionService,station a,station b where regionservice.stationid=a.id and a.pid=b.id and receivedt>='''+@begindt+''' and receivedt<='''+@enddt+''' and b.id in('+@stationIds+') and  regionservice.Type in (select CaseTypeIDS from CaseType where ProvinceCaseTypeIDS like ''' + @caseType + '%'') union all
select b.name ItemName,0 ServiceRc,1 PoliceRC from ArrangeInfo,station a,station b where arrangeinfo.stationid=a.id and a.pid=b.id and  workdt>='''+@begindt+''' and workdt<'''+@enddt+''' and b.id in('+@stationIds+') and  ShiftType in (' + @shiftType + '))a group by a.itemname order by itemname'
end
if(@type='派出所')
begin
set @sql='select a.ItemName,sum(a.ServiceRC) ServiceRC,isnull(sum(a.PoliceRC),0) PoliceRC from
( select a.name ItemName,1 ServiceRc,0 PoliceRC from RegionService,station a where regionservice.stationid=a.id and receivedt>='''+@begindt+''' and receivedt<='''+@enddt+''' and stationid in(select Id from dbo.[GetChildStations]('''+@stationIds+''',''station_isuse'')) and  regionservice.Type in (select CaseTypeIDS from CaseType where ProvinceCaseTypeIDS like ''' + @caseType + '%'') union all
select a.name ItemName,0 ServiceRc,1 PoliceRC from ArrangeInfo,station a where arrangeinfo.stationid=a.id and  workdt>='''+@begindt+''' and workdt<'''+@enddt+''' and stationid in(select Id from dbo.[GetChildStations]('''+@stationIds+''',''station_isuse''))  and  ShiftType in (' + @shiftType + '))a group by a.itemname order by itemname'
end
if(@type='警务区')
begin
set @sql='select a.ItemName,sum(a.ServiceRC) ServiceRC,isnull(sum(a.PoliceRC),0) PoliceRC from
( select a.name ItemName,1 ServiceRc,0 PoliceRC from RegionService,subregion a where regionservice.regionId=a.id and receivedt>='''+@begindt+''' and receivedt<='''+@enddt+''' and a.stationid in(select Id from dbo.[GetChildStations]('''+@stationIds+''',''station_isuse'')) and  regionservice.Type in (select CaseTypeIDS from CaseType where ProvinceCaseTypeIDS like ''' + @caseType + '%'') union all
select a.name ItemName,0 ServiceRc,1 PoliceRC from ArrangeInfo,subregion a where arrangeinfo.regionid=a.id and  workdt>='''+@begindt+''' and workdt<'''+@enddt+''' and a.stationid in(select Id from dbo.[GetChildStations]('''+@stationIds+''',''station_isuse'')) and  ShiftType in (' + @shiftType + '))a group by a.itemname order by itemname'
end
print @sql
exec (@sql)
--select '' ItemName,1 ServiceRc,2 PoliceRC -- from regionservice where receivedt>=begindt and receivedt<enddt and Station in
END
GO

