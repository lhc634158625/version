
CREATE PROCEDURE [dbo].[AutoFinishService]
	
AS
BEGIN
	declare @autoDoneTime int
	declare @maxid int
	select @autoDoneTime=autodonetime from systemparam
	
	select @maxid=MAX(id) from StaffWorkLog where ProcessDt is null and State in('ll0','自接')
	
	and DATEADD("MI",@autoDoneTime, ReceiveDt)<GETDATE() 	
		
	update Staff set State='待警'
	 where state in ('ll0','自接') and  not exists (select StaffId from StaffWorkLog w  where Staff.Id=w.StaffId and  w.ProcessDt is null and w.State in('ll0','自接')
	 )
	 
	 update SubRegion
	 set ServiceState='待警'
	 where  ServiceState not in('待警') and  not exists (select 1 from RegionService r where r.RegionId=SubRegion.Id and r.ProcessDt is null 
	 ) 
	 
	 update RegionShiftType set State='待警'
	 where State not in('待警') and shifttype=4 and not exists(select 1 from RegionService r where r.RegionId=RegionShiftType.RegionId and ProcessDt is null 
	 )
	 update RegionService set processdt=GETDATE()
	 where  ProcessDt is null and DATEADD("MI",@autoDoneTime, ReceiveDt)<GETDATE() 	 
	 update StaffWorkLog set ProcessDt=GETDATE() where ProcessDt is null and State in('ll0','自接')
	 and Id<=@maxid	 	
END
GO

