CREATE PROCEDURE [dbo].[DxcpUpdate]
	
AS
BEGIN
insert into SMSERVIVER.SMS.DBO.短信测评中间表(typedm,areadm,areadm_new,MOBILE,lsh,ALARM_EVENTID,CASE_ID,BDATE,alarm_TYPE,CALLER_NAME,ALARM_ADDRESS,ACCEPT_UNIT_NAME,REMARK,agent_id,jqh)--,feedback_log,feedback_time)	
select casetype.CaseTypeIDS typedm,AcceptUnitIDS areadm,AcceptUnitIDS areadm_new,
	MOBILE,ALARM_EVENTID lsh,ALARM_EVENTID,CASE_ID,BDATE,case_event_TYPE,CALLER_NAME,ALARM_ADDRESS,ACCEPT_UNIT_NAME,REMARK,agent_id,jqh--,feedback_log,feedback_time
	 	 from [ORASERVER]..[XM110].[DXCPZJB] 
	 		left join CaseType on RTRIM(CaseType)=RTRIM(case_event_type) ---改为案件类型非报警类型
	 		left join AcceptUnit on RTRIM(accept_unit_name)=RTRIM(UnitName)
		where right(case_id,20)=alarm_eventid and main_event_flag='y'		
			and bdate< {fn CURDATE()} 
			and bdate>(select MAX(bdate) from SMSERVIVER.SMS.DBO.短信测评中间表) 
			and (LEN(mobile) > 8 or LEFT(mobile, 1) = '8') 
			--and alarm_type not in ('居家开锁','移车服务','开锁服务','医疗急救','路灯抢修','污水抢修','影响市容')
			--and accept_unit_name is not null and accept_unit_name<>'全部处警单位' 
			order by bdate
	
END
GO

