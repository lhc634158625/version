-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[sf_CameraSpeed]
(
	-- Add the parameters for the function here
	@count numeric(4),
	@speed numeric(6,2),
	@maxinterval numeric(6,2),
	@mininterval numeric(6,2)
	
)
RETURNS int
AS
BEGIN
	if(@speed>0) return @speed
	if(@speed=0) or (@count=0) or (@maxinterval=0)  return  -1
	if(@count>0)
	begin
	
		if(@count<=10) and(@maxinterval>45) return @count
		if(@count<=10 and @maxinterval<=45) return 60*120/@maxinterval/@count
		if(@count>10) return @count
		
	end
	return 0

END
GO

