-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateTrafficFromFCD_EdgeSpeedNew] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	truncate table [FCD_EdgeSpeedNew]
	insert into [FCD_EdgeSpeedNew]
	select * from [GPSCENTER].[GPSFCD].[dbo].[FCD_EdgeSpeedNew]

	update TrafficInfo set TrafficInfo.Speed=[FCD_EdgeSpeedNew].SPEED, TrafficInfo.UpdatedDt=[FCD_EdgeSpeedNew].ENDTIME
	From [FCD_EdgeSpeedNew]
	where [FCD_EdgeSpeedNew].EDGEID=TrafficInfo.EdgeId and TrafficInfo.CheckDt<GETDATE()
	
	truncate table [FCD_EdgeSpeedNew_Bus]
	insert into [FCD_EdgeSpeedNew_Bus]
	select * from [GPSCENTER].[GPSFCD].[dbo].[FCD_EdgeSpeedNew_Bus]
	
	update TrafficInfo set TrafficInfo.BusSpeed=[FCD_EdgeSpeedNew_Bus].SPEED
	From [FCD_EdgeSpeedNew_Bus]
	where [FCD_EdgeSpeedNew_Bus].EDGEID=TrafficInfo.EdgeId and TrafficInfo.CheckDt<GETDATE()
	
	---岛外公交
	truncate table [FCD_EdgeSpeed_XMBUS]
	insert into [FCD_EdgeSpeed_XMBUS]
	select * from [GPSCENTER].[GPSFCD].[dbo].[FCD_EdgeSpeed_XMBUS]

	update TrafficInfo set TrafficInfo.Speed=[FCD_EdgeSpeed_XMBUS].SPEED, TrafficInfo.UpdatedDt=[FCD_EdgeSpeed_XMBUS].ENDTIME
	From [FCD_EdgeSpeed_XMBUS]
	where ([FCD_EdgeSpeed_XMBUS].EDGEID+40000)=TrafficInfo.EdgeId and TrafficInfo.CheckDt<GETDATE()
	
END
GO

