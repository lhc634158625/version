
CREATE PROCEDURE [dbo].[SynGPSData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	declare @maxDt DateTime
	declare @minDt DateTime
	select @minDt=GPSTime from syndatalog
	select @maxdt=MAX([StorageTime]) from [GPSCENTER].[TXServer].[dbo].[VehicleLastGps]
	insert into GPSInfo(DevCode,Longitude,Latitude,ReceiveDt,PosDesc,peoples,serviceId,StorageTime,createtime,[Attribute],[AlarmType],[Flag],[Speed],[Direction],[Mileage])
	select  a.[VehicleID]
	  ,a.[Longitude]
      ,a.[Latitude]
      ,a.[GpsDateTime]
      ,a.[Position],
      dbo.[GetStaffByDevCode](a.[VehicleID]),
      dbo.[GetServiceByDevCode](a.[VehicleID]),
      a.StorageTime,
      GETDATE(),
      a.[Attribute],
      a.[AlarmType],
      a.[Flag],
      a.[Speed],
      a.[Direction],
      a.[Mileage]
	from [GPSCENTER].[TXServer].[dbo].[VehicleLastGps] a
	where [StorageTime]>@mindt and   [StorageTime]<@maxdt
	and a.[Longitude]>100 and a.[Latitude]>20
	
	update syndatalog set GPSTime=@maxDt
	
	
	update DeviceInfo set State= (Case when  a.[IsOnLine]=1 then '在线' when a.[IsOnLine]=0 then '离线' else '离线' end)
	from [GPSCENTER].[TXServer].[dbo].[VehicleInfo] a
	where CONVERT(varchar(50),a.[VehicleID])=DeviceInfo.Code and a.[IsOnLine]=1
	
	update DeviceInfo set State ='离线'
	where isnull(DeviceInfo.LastPosTime,'2012-03-15') < GETDATE() -1
	
END
GO

