-- =============================================
CREATE PROCEDURE [dbo].[SynData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
return 
	declare @maxid varchar(50)
	declare @minid varchar(50)
	select @minid=commstateid from syndatalog
	select @maxid=MAX(commlsh) from [POLICECENTER].[policedb].[dbo].[comm_state]
	insert into CommunicateLog(commid,serviceid,created,callnum,calltype,RegionId,State,Station,PStation,[Hour])
	select [commlsh]
      ,[jjlsh]
      ,[calltime]
      ,[callid]
      ,[callws]      
      ,b.Id
      ,[callsta]
      ,b.StationId,
      c.PId,
      DATEPART(hour,[calltime])
	from [POLICECENTER].[policedb].[dbo].[comm_state] a,subregion b,Station c
	where  a.[commlsh] between @minid and @maxid
	and a.[callunit]=b.code and b.StationId=c.Id order by a.[commlsh]
	update syndatalog set commstateid=@maxid
	
END
GO

