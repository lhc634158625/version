

CREATE view [dbo].[vw_staffInfo]([Id]
      ,[Station]
      ,[Region]
      ,[Name]
      ,[Telephone]
      ,Position
      ,[Onduty]
      ,[VerhicleId]) 
      as
      select a.ID,b.Name Station,c.Name, a.Name,a.Telephone,d.Name,
      case 
      when State='备勤'
      then 0
      else
      1
      end ,       
      a.DevCode
      from staff a 
       left  outer join 
      Station b on a.Station=b.Id
      left outer join SubRegion c
      on a.RegionId=c.id
      left outer join Position d
      on a.Position=d.Id
      where a.Station in(select Id from Station where IsUse=1)

GO

