CREATE PROCEDURE [dbo].[SynCommData7DUpdate]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN

	update CommunicateLog 
	set SrcCallType=a.DISPATCH_TYPE,Station=c.Id,RegionId=0,Created=a.DISPATCH_TIME, CallNum=a.DISPATCH_DEV_ID,[Hour]=DATEPART(hour,a.DISPATCH_TIME),PStation=C.PId,CaseType=ct.CaseType,CaseTypeIDS=ct.CaseTypeIDS,
	[State]=(Case when a.dispatch_result='201' then '正常接通' when a.dispatch_result='202' then '处警中' when a.dispatch_result='203' then '超时应答' when a.dispatch_result='204' then '替代接' when a.dispatch_result='211' then '无人应答' when a.dispatch_result='212' then '信号差' when a.dispatch_result='213' then '接不通'  when a.DISPATCH_FLAG='Y' then '正常接通'  else '无人应答' end),
	callType=(Case when  SUBSTRING(a.DISPATCH_DEV_ID,0,2)='9' then '电台' when SUBSTRING(a.DISPATCH_DEV_ID,0,2)='0' and len(a.DISPATCH_DEV_ID)=12 then '手机' else '电话' end)
	from OpenQuery(ORASERVER, 'select *  from DISPATCH_LOG7D where DISPATCH_TIME > sysdate-0.4 and ACCEPT_UNIT_NAME not like ''%警务区''') a,TempUnits b, Station c,CaseType ct
	where a.DISPATCH_ID= CommunicateLog.dispatch_Id  and a.ACCEPT_UNIT_NAME=b.UnitName and b.StationId=c.Id  and a.case_event_type=ct.CaseType 
	
	update CommunicateLog 
	set SrcCallType=a.DISPATCH_TYPE,Station=c.Id,RegionId=b.Id,Created=a.DISPATCH_TIME, CallNum=a.DISPATCH_DEV_ID,[Hour]=DATEPART(hour,a.DISPATCH_TIME),PStation=C.PId,CaseType=ct.CaseType,CaseTypeIDS=ct.CaseTypeIDS,
	[State]=(Case when a.dispatch_result='201' then '正常接通' when a.dispatch_result='202' then '处警中' when a.dispatch_result='203' then '超时应答' when a.dispatch_result='204' then '替代接' when a.dispatch_result='211' then '无人应答' when a.dispatch_result='212' then '信号差' when a.dispatch_result='213' then '接不通'  when a.DISPATCH_FLAG='Y' then '正常接通'  else '无人应答' end),
	CallType=(Case when  SUBSTRING(a.DISPATCH_DEV_ID,0,2)='9' then '电台' when SUBSTRING(a.DISPATCH_DEV_ID,0,2)='0' and len(a.DISPATCH_DEV_ID)=12 then '手机' else '电话' end)
	from OpenQuery(ORASERVER, 'select *  from DISPATCH_LOG7D where DISPATCH_TIME > sysdate-0.4 and ACCEPT_UNIT_NAME like ''%警务区''') a,SubRegion b, Station c,CaseType ct
	where a.DISPATCH_ID= CommunicateLog.dispatch_Id and SUBSTRING(a.ACCEPT_UNIT_NAME,0,4)=b.Name and b.StationId=c.Id and a.case_event_type=ct.CaseType
		
END
GO

