
CREATE PROCEDURE [dbo].[AutoArrange_SWAT20140715] 
	(@workDt Date, @updater int)
AS
BEGIN
	declare @count int
	select @count = COUNT(*) from SWATPatrolHis where WorkDt=@workDt
	print @count
	if @count>0 return	
	
	insert SWATPatrolHis([SWATID],[Name],[PatrolArea],[Memo],[CenterX],[CenterY],[PoliceCode],[LeaderName],[LeaderPost],[LeaderPhone],[RadioFrequency],[RadioNo],[CarNo],[DutyNumber],[Time1Range],[FromTime1],[ToTime1],[WeaponryPike],[WeaponryPistols],[RiotDogNumber],[WorkDt],[Updater],[UpdateTime],[Created])
	select [SWATID],[Name],[PatrolArea],[Memo],[CenterX],[CenterY],[PoliceCode],[LeaderName],[LeaderPost],[LeaderPhone],[RadioFrequency],[RadioNo],[CarNo],[DutyNumber],[Time1Range],[FromTime1],[ToTime1],[WeaponryPike],[WeaponryPistols],[RiotDogNumber],@workDt,@updater,GETDATE(),GETDATE()
	from SWATPatrol
		
END

GO

