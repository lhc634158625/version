/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO13_u_ArrangeInfo] 
   ON  dbo.ArrangeInfo
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;	
    declare @Remark nvarchar(MAX)
    set @Remark= ''
    
set @Remark='NULL'    

    if @Remark !=''
    BEGIN
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey],[Fields])
    select 'DB47TO13' ,'dbo'  ,'ArrangeInfo' ,'Id=' + convert(varchar(50),inserted.Id),'U',0, 'UDB47TO13dboArrangeInfoId=' + convert(varchar(50),inserted.Id),@Remark
    from inserted
    End
END
GO

