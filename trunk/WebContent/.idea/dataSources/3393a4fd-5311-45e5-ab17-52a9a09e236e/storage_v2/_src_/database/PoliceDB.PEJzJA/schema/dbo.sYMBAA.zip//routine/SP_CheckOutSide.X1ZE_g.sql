Create PROCEDURE [dbo].[SP_CheckOutSide]
	@date Date
AS
BEGIN
select a.* from (
select a.StaffId,a.staffName,getdate() Created,ArrangeId,a.StationId,dbo.fn_distance(a.Longitude,a.Latitude,b.Longitude,b.Latitude) Distance,
	b.Longitude,b.Latitude,a.TimeType,a.TimeName
	from 
	(select a.Longitude,a.Latitude,b.Id ArrangeId,b.TimeType,b.TimeName, b.FromTime,b.ToTime,b.StaffId,c.HandsetCode,b.StaffName,b.StationId 
	from ShiftTime a,ArrangeInfo b,Staff c 
	where a.Id=b.TimeType and a.ShiftId=c.Id
	and WorkDt=@date and b.ShiftType=7 and a.Longitude is not null) a,GPSInfo b where 	
	a.HandsetCode=b.DevCode and b.ReceiveDt between a.FromTIme and a.ToTime	
	) a where distance>500
	
END
GO

