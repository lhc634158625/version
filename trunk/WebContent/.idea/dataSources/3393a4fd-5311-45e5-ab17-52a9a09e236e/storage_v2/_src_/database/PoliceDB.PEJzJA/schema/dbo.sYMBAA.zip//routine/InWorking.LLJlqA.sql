Create FUNCTION [dbo].[InWorking]
(
	-- Add the parameters for the function here
	@workdt datetime,
	@hour varchar(2),
	@fromdt datetime,
	@todt datetime
	
)
RETURNS int
AS
BEGIN
	declare @ret int
	declare @checkTime datetime
	set @ret=0
	set @checkTime=cast(convert(varchar(11),@workdt,120)+@hour+':00:00' as datetime)
	if(@checkTime>@fromdt and @checkTime<@toDt) set @ret=1

	return @ret

END
GO

