/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO132_d_BBSInfo] 
   ON  [dbo].[BBSInfo]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO132' ,'dbo'  ,'BBSInfo' ,'Id=' + convert(varchar(50),deleted.Id),'D',0,'DDB47TO132dboBBSInfoId=' + convert(varchar(50),deleted.Id) 
    from deleted
END
GO

