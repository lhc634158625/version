CREATE TRIGGER [dbo].[tr_updEdgeDetail]
   ON  [dbo].[EdgeDetail]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	update edgemaster set speed=a.speed ,cameraspeed=a.cameraspeed,busspeed=a.busspeed from
	(select masterid,avg(speed) speed,avg(cameraspeed) cameraspeed,avg(busspeed) busspeed from edgedetail where CameraSpeed>-1  group by masterid) a
	where edgemaster.id=a.masterid 
	and exists(select id from inserted where inserted.masterid=a.masterid)
    -- Insert statements for trigger here

END
GO

