

CREATE PROCEDURE [dbo].[CopyArrange_SWAT] 
	(@fromDt Date, @toDt Date, @sWATId int, @updater int)
AS
BEGIN
	if @fromDt=@toDt return
	declare @dayDiff int
	set @dayDiff = datediff(d,@fromDt,@toDt)
	
	insert SWATHis([SWATID]
      ,[Name]
      ,[PatrolArea]
      ,[Memo]
      ,[Longitude]
      ,[Latitude]
      ,[PoliceCode]
      ,[LeaderName]
      ,[LeaderPost]
      ,[LeaderPhone]
      ,[PoliceCode_1]
      ,[LeaderName_1]
      ,[LeaderPost_1]
      ,[LeaderPhone_1]
      ,[RadioGroup]
      ,[RadioFrequency]
      ,[RadioNo]
      ,[CarNo]
      ,[DutyNumber]
      ,[DutyNumber_1]
      ,[FromTime]
      ,[ToTime]
      ,[WeaponryPike]
      ,[WeaponryPistols]
      ,[RiotDogNumber]
      ,[WorkDt]
      ,[Updater]
      ,[UpdateDt]
      ,[Created])
	select [SWATID]
      ,[Name]
      ,[PatrolArea]
      ,[Memo]
      ,[Longitude]
      ,[Latitude]
      ,[PoliceCode]
      ,[LeaderName]
      ,[LeaderPost]
      ,[LeaderPhone]
      ,[PoliceCode_1]
      ,[LeaderName_1]
      ,[LeaderPost_1]
      ,[LeaderPhone_1]
      ,[RadioGroup]
      ,[RadioFrequency]
      ,[RadioNo]
      ,[CarNo]
      ,[DutyNumber]
      ,[DutyNumber_1]
      ,DATEADD(DAY, @dayDiff, [FromTime])
      ,DATEADD(DAY, @dayDiff, [ToTime])
      ,[WeaponryPike]
      ,[WeaponryPistols]
      ,[RiotDogNumber]
      ,@toDt
      ,@updater
      ,GETDATE()
      ,GETDATE()
	from SWATHis where WorkDt=@fromDt
		and SWATID in (select Id from PointInfo where (Id=@sWATId or OwnerId=@sWATId) and [State]='启用')
		and SWATID not in (select SWATID from SWATHis where WorkDt=@toDt)
		
END


GO

