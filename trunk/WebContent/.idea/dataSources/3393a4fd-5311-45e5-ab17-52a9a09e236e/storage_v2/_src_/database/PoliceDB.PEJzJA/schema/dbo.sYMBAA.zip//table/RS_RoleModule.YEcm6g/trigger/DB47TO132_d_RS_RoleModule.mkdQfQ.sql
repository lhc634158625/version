/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO132_d_RS_RoleModule] 
   ON  [dbo].[RS_RoleModule]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO132' ,'dbo'  ,'RS_RoleModule' ,'Id=' + convert(varchar(50),deleted.Id),'D',0,'D+DB47TO132+dbo+RS_RoleModule+Id=' + convert(varchar(50),deleted.Id) 
    from deleted
END
GO

