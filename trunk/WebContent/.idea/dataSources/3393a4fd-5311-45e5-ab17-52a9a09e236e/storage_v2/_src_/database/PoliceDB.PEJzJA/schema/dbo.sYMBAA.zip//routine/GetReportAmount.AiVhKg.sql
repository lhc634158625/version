CREATE FUNCTION [dbo].[GetReportAmount]
(
	-- Add the parameters for the function here
	@stationCode varchar(10),
	@shiftType int=0,
	@state varchar(50)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ret int

	-- Add the T-SQL statements to compute the return value here
	if(@shiftType=0)
		if(@state='All')
			select @ret=count(id) from staff where station in(select id from station where code like @stationCode+'%')
		else
			select @ret=count(id) from staff where station in(select id from station where code like @stationCode+'%') and state=@state
	else
	if(@state='All')
			select @ret=count(id) from staff where shiftType=@shifttype and station in(select id from station where code like @stationCode+'%')
		else
			select @ret=count(id) from staff where shiftType=@shifttype and station in(select id from station where code like @stationCode+'%') and state=@state
	

	-- Return the result of the function
	RETURN @ret

END
GO

