create FUNCTION  [dbo].[GetSingleTotalCount]
(
	-- Add the parameters for the function here
	@stationId int,
	@stationName varchar(50),
	@type varchar(50)
)
RETURNS int
AS
BEGIN
  declare @thiscount int
  if(@type='派出所')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from station where isnull(isuse,0)=1 and name like '%派出所' 
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from station where Id in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) and isnull(isuse,0)=1 and name like '%派出所' 
		else
			 return 1
	end
if(@type='派出所人数')
if @stationId=123
	  select @thiscount=count(id) from staff where station in(select Id from station where isnull(isuse,0)=1 and name like '%派出所') 
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from staff where station in(select Id from station where pid=@stationId and isnull(isuse,0)=1 and name like '%派出所') 
		else			
			select @thiscount=count(id) from staff where station=@stationId
if(@type='交警')
if @stationId=123
	  select @thiscount=count(id) from station where isnull(isuse,0)=1 and name like '%交警%' 
	  else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from station where isnull(isuse,0)=1 and name like '%交警%' and Id in(select Id from dbo.GetChildStations(@stationId,'station_isuse'))
		else	
			return 1 
if(@type='交警人数')
	  if @stationId=123
		select @thiscount=count(id) from staff where station in(select id from station where isnull(isuse,0)=1 and name like '%交警%' ) 
	   else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from staff where station in(select Id from station where Id in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) and isnull(isuse,0)=1 and name like '%交警%') 
		else	
			select @thiscount=count(id) from staff where station=@stationId

if(@type='武装盘查')
  if @stationId=123
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%盘查%'
	   else
		if(CHARINDEX('分局',@stationName)>1)
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%盘查%' and stationId in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) 			
		else	
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%盘查%' and stationId in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) 				 
if(@type='武装盘查人数')
 if @stationId=123
		SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%盘查%' )  and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
    else
		if(CHARINDEX('分局',@stationName)>1)
		 SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%盘查%'   and stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) )and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
		else	
		 SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%盘查%'   and stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) )and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
if(@type='检查站')
  if @stationId=123
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%卡点' 
	   else
		if(CHARINDEX('分局',@stationName)>1)
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%卡点'  and stationId in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) 			
		else	
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%卡点'  and stationId in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) 				 
if(@type='检查站人数')
 if @stationId=123
		SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%卡点'  )  and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
    else
		if(CHARINDEX('分局',@stationName)>1)
		 SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%卡点'    and stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) )and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
		else	
		 SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%卡点'   and stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) )and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
if(@type='巡特警')
  if @stationId=123
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%特警%' 
	   else
		if(CHARINDEX('分局',@stationName)>1)
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%特警%'  and stationId in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) 			
		else	
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%特警%'  and stationId in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) 				 
if(@type='巡特警人数')
 if @stationId=123
		SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%特警%'  )  and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
    else
		if(CHARINDEX('分局',@stationName)>1)
		 SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%特警%'    and stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) )and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
		else	
		 SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%特警%'   and stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) )and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 

if(@type='围村围点')
  if @stationId=123
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%围村%' 
	   else
		if(CHARINDEX('分局',@stationName)>1)
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%围村%'   and stationId in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) 			
		else	
		 select @thiscount=count(id) from [PointInfo] where OwnerType like '%围村%'   and stationId in(select Id from dbo.GetChildStations(@stationId,'station_isuse')) 				 
if(@type='围村围点人数')
 if @stationId=123
		SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%围村%'   )  and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
    else
		if(CHARINDEX('分局',@stationName)>1)
		 SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%围村%'     and stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) )and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 
		else	
		 SELECT @thiscount=sum(cast([DutyNumber] as Int)) FROM SWATHis where SWATID in(select ID from [PointInfo] where OwnerType like '%围村%'    and stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) )and FromTime>CAST(CONVERT(varchar(10),getdate(),120) as datetime)  and ToTime>GETDATE() 



if(@type='警务区')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from subregion where isnull(isuse,0)=1
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from subregion where stationId in(select Id from dbo.GetChildIds(@stationId,'station_isuse')) and isnull(isuse,0)=1
		else
			select @thiscount= count(id) from subregion where stationId=@stationId and isnull(isuse,0)=1
	end
	 if(@type='巡逻车')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from deviceinfo where  type='巡逻车台'
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from deviceinfo where stationId=@stationId  and type='巡逻车台'
		else
			select @thiscount= count(id) from deviceinfo where stationId=@stationId  and type='巡逻车台'
	end
	if(@type='巡逻车在线')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from deviceinfo where type='巡逻车台' and state='在线'
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from deviceinfo where stationId=@stationId  and type='巡逻车台' and state='在线'
		else
			select @thiscount= count(id) from deviceinfo where stationId=@stationId  and type='巡逻车台'and state='在线'
	end
	if(@type='群防群治')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from deviceinfo where type='群防群治' and state='在线'
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from deviceinfo where stationId=@stationId  and type='群防群治' and state='在线'
		else
			select @thiscount= count(id) from deviceinfo where stationId=@stationId  and type='群防群治'and state='在线'
	end
	
	if(@type='单兵设备')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from deviceinfo where type in('单兵电台（多模）','单兵电台(单模)','执法记录仪')
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from deviceinfo where stationId=@stationId and type in('单兵电台（多模）','单兵电台(单模)','执法记录仪')
		else
			select @thiscount= count(id) from deviceinfo where stationId=@stationId and type in('单兵电台（多模）','单兵电台(单模)','执法记录仪')
	end
	if(@type='单兵设备在线')
  begin
	 if @stationId=123
		select @thiscount=count(id) from deviceinfo where  type in('单兵电台（多模）','单兵电台(单模)','执法记录仪') and state='在线'
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from deviceinfo where stationId=@stationId  and type in('单兵电台（多模）','单兵电台(单模)','执法记录仪') and state='在线'
		else
			select @thiscount= count(id) from deviceinfo where stationId=@stationId and type in('单兵电台（多模）','单兵电台(单模)','执法记录仪') and state='在线'
	end
	
	if(@type='群防辅警')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from deviceinfo where type in('群防辅警','群防设备')
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from deviceinfo where stationId=@stationId and type in('群防辅警','群防设备')
		else
			select @thiscount= count(id) from deviceinfo where stationId=@stationId and type in('群防辅警','群防设备')
	end
	if(@type='群防辅警在线')
	begin
		if @stationId=123
			select @thiscount=count(id) from deviceinfo where  type in('群防辅警','群防设备') and state='在线'
		else
			if(CHARINDEX('分局',@stationName)>1)
				select @thiscount=count(id) from deviceinfo 
				where stationId=@stationId and type in('群防辅警','群防设备') and state='在线'
			else
				select @thiscount= count(id) from deviceinfo where stationId=@stationId and type in('群防辅警','群防设备') and state='在线'
	end
	if(@type='ll0')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from SubRegion where isnull(isuse,0)=1 and ServiceState='ll0'
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from SubRegion where stationId=@stationId and  isnull(isuse,0)=1 and ServiceState='ll0'
		else
			select @thiscount= count(id) from SubRegion where isnull(isuse,0)=1  and stationId=@stationId and ServiceState='ll0'
	end
	if(@type='自接')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from SubRegion where isnull(isuse,0)=1 and ServiceState='自接'
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from SubRegion where stationId=@stationId  and  isnull(isuse,0)=1 and ServiceState='自接'
		else
			select @thiscount= count(id) from SubRegion where isnull(isuse,0)=1  and stationId=@stationId and  ServiceState='自接'
	end
	if(@type='24小时接处警')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from RegionService where  ReceiveDt>=dateadd(hour,-24,GETDATE())
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from RegionService where stationId=@stationId  and  ReceiveDt>=dateadd(hour,-24,GETDATE())
		else
			select @thiscount= count(id) from RegionService where stationId=@stationId and   ReceiveDt>=dateadd(hour,-24,GETDATE())
	end
	if(@type='刑事')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from RegionService where type like '00001%' and  ReceiveDt>=dateadd(hour,-24,GETDATE()) 
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from RegionService where stationId=@stationId  and  type like '00001%' and   ReceiveDt>=dateadd(hour,-24,GETDATE())
		else
			select @thiscount= count(id) from RegionService where stationId=@stationId and    type like '00001%' and ReceiveDt>=dateadd(hour,-24,GETDATE())
	end
	if(@type='治安')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from RegionService where  (type like '00002%' or type like '00004%')  and  ReceiveDt>dateadd(hour,-24,GETDATE())
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from RegionService where stationId=@stationId  and   (type like '00002%' or type like '00004%')  and   ReceiveDt>=dateadd(hour,-24,GETDATE())
		else
			select @thiscount= count(id) from RegionService where stationId=@stationId and    (type like '00002%' or type like '00004%')  and ReceiveDt>=dateadd(hour,-24,GETDATE())
	end
	if(@type='民事')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from RegionService where type like '00007%' and  ReceiveDt>=dateadd(hour,-24,GETDATE()) 
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from RegionService where stationId=@stationId  and  type like '00007%' and   ReceiveDt>=dateadd(hour,-24,GETDATE())
		else
			select @thiscount= count(id) from RegionService where stationId=@stationId and    type like '00007%' and ReceiveDt>=dateadd(hour,-24,GETDATE())
	end
	if(@type='交通')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from RegionService where type like '00003%' and  ReceiveDt>=dateadd(hour,-24,GETDATE()) 
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from RegionService where stationId=@stationId  and  type like '00003%' and   ReceiveDt>=dateadd(hour,-24,GETDATE())
		else
			select @thiscount= count(id) from RegionService where stationId=@stationId and    type like '00003%' and ReceiveDt>=dateadd(hour,-24,GETDATE())
	end
	if(@type='备勤')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from Staff where  ShiftState in('备勤','离岗') --not exists(select staffid from ArrangeInfo where   getdate() between fromtime and totime and  ArrangeInfo.StaffId=Staff.Id  )
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from Staff where   ShiftState in('备勤','离岗') and station=@stationId  
		else
			select @thiscount= count(id) from Staff where   ShiftState in('备勤','离岗') and station=@stationId 
	end
	if(@type='在岗')
  begin
	 if @stationId=123
	  select @thiscount=count(id) from Staff where   ShiftState in('在岗','到岗')
	 else
		if(CHARINDEX('分局',@stationName)>1)
			select @thiscount=count(id) from Staff where    ShiftState in('在岗','到岗') and station=@stationId 
		else
			select @thiscount= count(id) from Staff where station=@stationId and     ShiftState in('在岗','到岗')
	end
return isnull(@thiscount,0)

END
GO

