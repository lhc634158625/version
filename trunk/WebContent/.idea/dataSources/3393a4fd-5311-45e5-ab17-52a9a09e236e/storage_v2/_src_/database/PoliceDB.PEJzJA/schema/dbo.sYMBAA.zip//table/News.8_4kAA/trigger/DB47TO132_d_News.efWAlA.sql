/******AUTO CREATE BY DM_[]******/
CREATE TRIGGER [dbo].[DB47TO132_d_News] 
   ON  [dbo].[News]
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;	
    INSERT INTO [dbo].[DMSyncData]
        ([TaskName],[Schem],[TableName],[PK],[Type],[Status],[IndexKey])
    select 'DB47TO132' ,'dbo'  ,'News' ,'ID=' + convert(varchar(50),deleted.ID),'D',0,'DDB47TO132dboNewsID=' + convert(varchar(50),deleted.ID) 
    from deleted
END
GO

