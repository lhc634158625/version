-- =============================================
CREATE PROCEDURE [dbo].[SynFKSCData]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	update RegionService set FKSC=a.FKSC
	from [100.168.110.28]..[SJJH].[FKDB] a
	where (a.JJDBH='350200'+RIGHT(RegionService.case_id,20)	
	and RegionService.CASE_ID is not null)
	and FKSJ >GETDATE()-17	and a.FKSC is not null
	
	
	--update RegionService set FKSC=a.FKSC
	--from [100.168.110.28]..[DSDB].[FKDB] a
	--where (a.JJDBH=rtrim('350200'+RegionService.ServiceId)
	--and RegionService.ServiceId is not null)
	--and FKSJ >GETDATE()-65	and FKSJ < GETDATE()-15
END
GO

