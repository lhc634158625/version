CREATE PROCEDURE [dbo].[StaffReport]
	-- Add the parameters for the stored procedure here
	@StationCode  varchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	select count(id) RecordCount,ShiftType,State from staff
	where Station in(select Id from Station where Code like  @StationCode+'%')
	group by ShiftType,state order by ShiftType
END
GO

