Create PROCEDURE [dbo].[SynCommData_Comm_State]
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	declare @maxid varchar(50)
	declare @minid varchar(50)
	select @minid=commstateid from syndatalog
	select @maxid=MAX(commlsh) from [POLICECENTER].[policedb].[dbo].[comm_state]
	insert into CommunicateLog(commid,serviceid,created,callnum,calltype,RegionId,State,Station,PStation,[Hour])
	select [commlsh]
      ,[jjlsh]
      ,[calltime]
      ,[callid]
      ,[callws]      
      ,b.Id
      ,[callsta]
      ,b.StationId,
      c.PId,
      DATEPART(hour,[calltime])
	from [POLICECENTER].[policedb].[dbo].[comm_state] a,subregion b,Station c
	where  a.[commlsh]>@minid and  a.[commlsh]<=@maxid
	and a.[callunit]=b.code and b.StationId=c.Id order by a.[commlsh]
	insert into CommunicateLog(commid,serviceid,created,callnum,calltype,RegionId,State,Station,PStation,[Hour])
	select [commlsh]
      ,[jjlsh]
      ,[calltime]
      ,[callid]
      ,[callws]      
      ,0
      ,[callsta]
      ,C.Id,
     case c.PId
     when 1 then c.Id
     else
     c.PId
     end ,
      DATEPART(hour,[calltime])
	from [POLICECENTER].[policedb].[dbo].[comm_state] a,Station c
	where  a.[commlsh]>@minid and  a.[commlsh]<=@maxid and c.IsUse=1
	and a.[callunit]=C.InnerCode  order by a.[commlsh]
	
	update syndatalog set commstateid=@maxid
	
END
GO

